function [LCA, Mass] = nk_runfse_lca(KPI, Mass0,method,reference)


if method == "recipe"

    %%% Inputs from technosphere
    names = ["ammonium_sulfate","ash","brine","co2","electricity","enzyme","ethanol","sodium_hydroxide","steam","sulfuric_acid","transport","water_deionised","wheat_straw","water"];
    categories = ["GW","OD","IR","OH","FP","OT","TA","FT","MT","TE","FE","ME","HC","HN","LU","MR","FR","WC"];
    
    Mass = struct();
    Mass.Feedstock = Mass0(1);
    Mass.Acid = Mass0(2);
    Mass.Enzyme = Mass0(3);
    Mass.Nitrogen = Mass0(4);
    Mass.Base = Mass0(5);
    Mass.Water_Net = Mass0(6);
    Mass.Ethanol = Mass0(7);
    Mass.CO2_fossil_in = Mass0(8);
    Mass.Brine = Mass0(9);
    Mass.Ashes = Mass0(10);
    Mass.Distance = Mass0(11);
    Mass.Steam_Net = Mass0(12);
    Mass.El_Net = Mass0(13);
    Mass.Cooling_Makeup = Mass0(14);
    Mass.Ccooling_Makeup = Mass0(15);
    Mass.CO2_fossil_out = Mass0(16);
    Mass.CO2_biogen = Mass0(17);
    
    % Characterization factors
    factors = struct();
    
    for i = 1:length(names)   
        factors.(names(i)) = readmatrix(sprintf("characterization_factors_recipe/%s.xlsx",names(i)),"Range","C17:C34");
    end
    
    factors.co2_fo = zeros(18,1);
    factors.co2_fo(1,1) = 1;
    factors.co2_bo = zeros(18,1);
    
    % Characterization results
    charfactors = ones(18,17);
    
    charfactors(:,1) = factors.wheat_straw .* Mass.Feedstock;                          % Wheat straw
    charfactors(:,2) = factors.sulfuric_acid .* Mass.Acid;                             % Sulfuric acid
    charfactors(:,3) = factors.enzyme .* Mass.Enzyme;                                  % Enzymes (NZ Cellic CTec 3)
    charfactors(:,4) = factors.ammonium_sulfate .* Mass.Nitrogen;                      % Nitrogen source (ammonium sulfate)
    charfactors(:,5) = factors.sodium_hydroxide .* Mass.Base;                          % Base & Titrant (sodium hydroxide)
    charfactors(:,6) = factors.water_deionised .* Mass.Water_Net;                      % Process Water
    charfactors(:,7) = factors.ethanol .* Mass.Ethanol;                                % Antisolvent (ethanol)
    charfactors(:,8) = factors.co2 .* Mass.CO2_fossil_in;                              % CO2 for Succinic Acid Fermentation
    charfactors(:,9) = factors.brine .* Mass.Brine;                                    % Brine from wwt
    charfactors(:,10) = factors.ash .* Mass.Ashes;                                     % Ash from combustion
    charfactors(:,11) = factors.transport .* (Mass.Distance * Mass.Feedstock);         % Transportation to and from plant on average
    charfactors(:,12) = factors.steam .* Mass.Steam_Net;                               % Steam for process
    charfactors(:,13) = factors.electricity * (Mass.El_Net*3600*24*300)*1e3;           % Electricity from onshore wind energy in Denmark * 1e3 for units
    charfactors(:,14) = factors.water * Mass.Cooling_Makeup;                           % Cooling and chilling water makeup
    charfactors(:,15) = factors.water * Mass.Ccooling_Makeup;
    charfactors(:,16) = factors.co2_fo * Mass.CO2_fossil_out;
    charfactors(:,17) = factors.co2_bo * Mass.CO2_biogen;

    charfactors = charfactors ./ Mass.Feedstock;
   
    charsum = sum(charfactors,2);
    
    % Normalization
    normfactors = [1.25e-4, 1.67e1, 2.08e-3, 4.86e-2, 3.91e-2, 5.63e-2, 2.44e-2, 1.54e0, 2.17e-1, 6.58e-5, 3.97e-2, 2.30e-2, 9.71e-2, 3.20e-5, 1.62e-4, 8.33e-6, 1.02e-3, 3.75e-3]; 
    
    charnorm = charsum .* normfactors';
    
    % Export
    LCA = struct();
    
    for i = 1:length(categories)   
        LCA.(categories(i)) = charnorm(i);
    end

elseif method == "impact2002+"

    %%% Inputs from technosphere
    names = ["ammonium_sulfate","ash","brine","co2","electricity","enzyme","ethanol","sodium_hydroxide","steam","sulfuric_acid","transport","water_deionised","wheat_straw","water"];
    categories = ["CC","NC","RI","IR","OD","RO","AE","TE","TA","LO","AA","AT","GW","NR","ME"];
    
    Mass = struct();
    Mass.Feedstock = Mass0(1);
    Mass.Acid = Mass0(2);
    Mass.Enzyme = Mass0(3);
    Mass.Nitrogen = Mass0(4);
    Mass.Base = Mass0(5);
    Mass.Water_Net = Mass0(6);
    Mass.Ethanol = Mass0(7);
    Mass.CO2_fossil_in = Mass0(8);
    Mass.Brine = Mass0(9);
    Mass.Ashes = Mass0(10);
    Mass.Distance = Mass0(11);
    Mass.Steam_Net = Mass0(12);
    Mass.El_Net = Mass0(13);
    Mass.Cooling_Makeup = Mass0(14);
    Mass.Ccooling_Makeup = Mass0(15);
    Mass.CO2_fossil_out = Mass0(16);
    Mass.CO2_biogen = Mass0(17);
    
    % Characterization factors
    factors = struct();
    
    for i = 1:length(names)   
        factors.(names(i)) = readmatrix(sprintf("characterization_factors_impact2002+/%s.xlsx",names(i)),"Range","C17:C31");
    end

    factors.co2_fo = zeros(15,1);
    factors.co2_fo(1,1) = 1;
    factors.co2_bo = zeros(15,1);
    
    % Characterization results
    charfactors = ones(15,17);
    
    charfactors(:,1) = factors.wheat_straw .* Mass.Feedstock;                          % Wheat straw
    charfactors(:,2) = factors.sulfuric_acid .* Mass.Acid;                             % Sulfuric acid
    charfactors(:,3) = factors.enzyme .* Mass.Enzyme;                                  % Enzymes (NZ Cellic CTec 3)
    charfactors(:,4) = factors.ammonium_sulfate .* Mass.Nitrogen;                      % Nitrogen source (ammonium sulfate)
    charfactors(:,5) = factors.sodium_hydroxide .* Mass.Base;                          % Base & Titrant (sodium hydroxide)
    charfactors(:,6) = factors.water_deionised .* Mass.Water_Net;                      % Process Water
    charfactors(:,7) = factors.ethanol .* Mass.Ethanol;                                % Antisolvent (ethanol)
    charfactors(:,8) = factors.co2 .* Mass.CO2_fossil_in;                              % CO2 for Succinic Acid Fermentation
    charfactors(:,9) = factors.brine .* Mass.Brine;                                    % Brine from wwt
    charfactors(:,10) = factors.ash .* Mass.Ashes;                                     % Ash from combustion
    charfactors(:,11) = factors.transport .* (Mass.Distance * Mass.Feedstock);         % Transportation to and from plant on average
    charfactors(:,12) = factors.steam .* Mass.Steam_Net;                               % Steam for process
    charfactors(:,13) = factors.electricity * (Mass.El_Net*3600*24*300) * 1e3;               % Electricity from onshore wind energy in Denmark * 1e3 for units
    charfactors(:,14) = factors.water * Mass.Cooling_Makeup;                           % Cooling and chilling water makeup
    charfactors(:,15) = factors.water * Mass.Ccooling_Makeup;
    charfactors(:,16) = factors.co2_fo * Mass.CO2_fossil_out;
    charfactors(:,17) = factors.co2_bo * Mass.CO2_biogen;

    charfactors = charfactors ./ Mass.Feedstock;
   
    charsum = sum(charfactors,2);


%     succinic_acid = [0.081012, 0.0446677, 0.00287, 32.80597, 5.05e-7, 0.002092, 319.7659, 74.85384, 0.035379, 0.025018, 0.01074, 0.000453, 3.022349, 71.73968, 0.066854];
%     charsum = charsum - (succinic_acid .* reference(2) ./ (reference(1) * 1000));

    % Export
    LCA = struct();
    
    for i = 1:length(categories)   
        LCA.(categories(i)) = charsum(i);
    end

end
