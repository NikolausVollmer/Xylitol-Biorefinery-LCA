clear
close all
clc

addpath("../sampling")
addpath("../models")

rng(42,'twister')

[T, configIDs] = nk_ctable;

cIDs = [2];
N = 1000;
method = "impact2002+"; % "recipe", "impact2002+"
reduced = "xo"; % "xo"

X = [0.3097, 47, 0.07392, 0.9907, 0.5881];
    

for i=1:length(cIDs) 
    cID = cIDs(i);

    configID = configIDs{cID}; 
    space    = nk_designSpace(configID); show(space);

    %% Sampling with boundary points
    red = reduced_space(cID);

    % Start Aspen
    HF = StartAspen("HF");
    CF = StartAspen("CF");
    LF = StartAspen("LF");
    Aspen = struct("HF", HF, "CF", CF, "LF", LF);

    %  input space
    xr = X(i,:);
    x = space.SetPoints;
    x(red) = xr;

    % run simulation
    [KPI0,Mass0] = nk_runfse_mass(x,space,configID,Aspen)
    Mass0.Feedstock = 150000e3; % 150000 t/a
    distance = 100; % average transport distance in km
    
    % close aspen
    CloseAspen(CF);
    CloseAspen(HF);
    CloseAspen(LF);
    clear Aspen CF HF LF

    mcsfolder = sprintf('c%d_mcsims_%s',cID,method); % name of the folder where for iters are stored
    if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end
    
    %% Distributions
    Masses = [Mass0.Feedstock, Mass0.Acid, Mass0.Enzyme, Mass0.Nitrogen, Mass0.Base + Mass0.Titrant, Mass0.Water_Net, Mass0.Ethanol,...
              Mass0.CO2_succ_in - Mass0.CO2_succ_out, Mass0.Brine, Mass0.Ashes, distance, Mass0.Steam_Net, Mass0.El_Net, ...
              Mass0.Cooling_Makeup, Mass0.Ccooling_Makeup, 0, Mass0.CO2_biogen];

    if reduced == "xo"
        Masses(3) = 0;
        Masses(4) = 1300;
        Masses(5) = 8968;
        Masses(6) = 10709500;

        Masses(8) = 0;
        Masses(9) = 0.5 * Masses(9);

        Masses(12) = 1109600000;
        Masses(13) = 0;
        Masses(14) = 0.5 * Masses(14);
        Masses(15) = 0;

        Masses(17) = 382000;
    end
    
    reference = [Mass0.Xylitol, Mass0.Succinic_Acid];
    %% Simulation        
    [LCA,Mass] = nk_runfse_lca_compare(KPI0,Masses,method,reference)

    % Save run
    save(sprintf("c%d_LCA_%s",cID,method))

end

function red = reduced_space(cID)

red_cID1 = [9,21,25,27,29];
red_cID2 = [7,15,18,20,22];
red_cID3 = [8,19,24,25,27];
red_cID4 = [6,13,17,18,20];

red_cID9 = [9,21,26,27,28];
red_cID10 = [7,15,19,20,21];
red_cID11 = [8,19,23,25,26];
red_cID12 = [6,13,16,18,19];

red_cID17 = [8,19,23,25,27];
red_cID18 = [6,13,16,18,20];
red_cID19 = [7,17,22,23,25];
red_cID20 = [5,11,15,16,18];

red_cID25 = [8,19,24,25,26];
red_cID26 = [6,13,17,18,19];
red_cID27 = [7,17,22,23,24];
red_cID28 = [5,11,14,16,17];

red_0 = [0,0,0,0,0];

red_cID = [red_cID1;red_cID2;red_cID3;red_cID4;
           red_0;red_0;red_0;red_0;
           red_cID9;red_cID10;red_cID11;red_cID12;
           red_0;red_0;red_0;red_0;
           red_cID17;red_cID18;red_cID19;red_cID20;
           red_0;red_0;red_0;red_0;
           red_cID25;red_cID26;red_cID27;red_cID28;
           red_0;red_0;red_0;red_0];


red = red_cID(cID,:);

end

