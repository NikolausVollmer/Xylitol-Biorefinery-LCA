load c2_LCA.mat

lcatable = table2array(To);
lcatable = lcatable(:,[1:18])
lcamean = mean(lcatable,1);
lcasigma = std(lcatable)

bar(1:15,lcamean);
xticklabels(["GW","OD","IR","OH","FP","OT","TA","FT","MT","TE","FE","ME","HC","HN","LU","MR","FR","WC"]);
hold on


err = errorbar(1:15,lcamean,lcamean-lcasigma,lcamean+lcasigma)
err.LineStyle = "none";



hold off