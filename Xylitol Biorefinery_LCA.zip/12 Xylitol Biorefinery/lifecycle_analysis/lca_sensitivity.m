addpath('../easyGSA/')
load c2_LCA_recipe_1000.mat

X = table2array(Ti);
Y = table2array(To);

%manipulation of the fossil output
X(1,16) = 0.1;

categories = ["GW","OD","IR","OH","FP","OT","TA","FT","MT","TE","FE","ME","HC","HN","LU","MR","FR","WC"];
masses = ["Feedstock","Acid","Enzyme","Nitrogen","Base","Titrant","Process Water","Ethanol","CO2 (fossil) in","CO2 (biogen) out","Brine","Ashes","Distance","Steam","Electricity","Cooling","Chilling"];


Sistruct = struct();
STistruct = struct();

for i = 1:18
    data.X = X;
    data.Y = Y(:,i);
    [Si,STi,results] = easyGSA('UserData',data, ...
                               'UseSurrogate','ANN')

    Sistruct.(categories(i)) = Si;
    STistruct.(categories(i)) = STi;

end

Simatrix = table2array(struct2table(Sistruct));
STimatrix = table2array(struct2table(STistruct));

figure()
heatmap(categories,masses,Simatrix)

figure()
heatmap(categories,masses,STimatrix)

writematrix(Simatrix,"Simatrix.csv")
writematrix(STimatrix,"STimatrix.csv")

save("c2_LCA_sensitivity")