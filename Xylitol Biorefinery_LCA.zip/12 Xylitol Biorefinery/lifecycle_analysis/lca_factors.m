function factors = lca_factors(inputs)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here



end

