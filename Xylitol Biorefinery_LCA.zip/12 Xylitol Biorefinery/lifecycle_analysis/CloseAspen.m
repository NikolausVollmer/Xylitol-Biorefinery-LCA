function CloseAspen(Aspen)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
Aspen.Close;
Aspen.Quit;
clear Aspen;

end

