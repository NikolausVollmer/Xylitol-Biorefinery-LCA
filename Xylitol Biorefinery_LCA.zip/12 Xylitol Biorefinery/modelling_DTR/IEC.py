"""
Created on Wed Sep 17 2020
@author: nikov@kt.dtu.dk

File containing functions for the routine for the mesh reduction to incrementally contract edges based on quadric error metrics
and an external calculated error

"""
import sys
import numpy as np
import itertools
from collections import Counter, defaultdict
import copy
from scipy.interpolate import interp1d
from scipy.spatial import ConvexHull, Delaunay
from IEC_functions import quadrics_Abc, barycentric_coordinates

def categorize_mesh(dictData):
    # 0. initialize output dictionary for function
    dictMesh = dict()

    sindices = dictData["sindices"]
    simplices = dictData["simplices"]

    vindices = dictData["vindices"]
    vertices = dictData["vertices"]

    triangulation = dictData["triangulation"]
    dim = dictData["dim"]

    # 1. Categorize vertices
    # 1.1 Calculate convex hull including coplanar points
    chull = ConvexHull(vertices, qhull_options='Qc')

    # 1.2 Assign hull vertices as points constituting the convex hull
    hvindices = chull.vertices

    # 1.3 Assign coplanar points to the convex hull as boundary vertices if existing
    if len(chull.coplanar) > 0:
        bvindices = chull.coplanar[:,0].tolist()

    else:
        bvindices = []

    # 1.3 Define outer vertices indices
    ovindices = np.union1d(hvindices,bvindices).astype(int)

    # 1.4 Define inner vertices indices
    ivindices = np.setdiff1d(vindices,ovindices).astype(int)

    # 2. Calculate edges
    eindices = list()

    # 2.1 for each simplex make combinations of two vertices which are in the simplex
    for sindex in sindices:
        eindices.extend([list(subset)
                         for subset in itertools.combinations(sindex, 2)])

    # 2.2 sort out duplicates
    eindices = set(
        tuple(
            tuple(
                sorted(
                    vindex for vindex in eindex))
            for eindex in eindices))

    # 2.3 make list out of set
    eindices = list(
        list(
            vindex for vindex in eindex)
        for eindex in eindices)

    # 2.4 make numpy array out of eindices, create edges from eindices with vertices
    eindices = np.array(eindices)
    edges = vertices[eindices]


    # 3. Categorize edges
    # 3.1 Outer edges
    oeindices = eindices[np.nonzero(np.prod(np.isin(eindices,ovindices).astype(int), axis=1))[0]]

    # 3.4 Constitutional edges, hull edges, boundary edges and outer mixed edges from outer edges
    ceindices = list()
    heindices = list()
    beindices = list()
    omeindices = list()

    for i in range(len(oeindices)):
        vi0 = oeindices[i][0]
        vi1 = oeindices[i][1]

        invi0 = np.where(np.sum(np.isin(sindices,vi0).astype(int), axis=1))[0]
        invi1 = np.where(np.sum(np.isin(sindices,vi1).astype(int), axis=1))[0]

        if len(np.intersect1d(invi0,invi1)) >= dim[0]:
            ceindices.append(oeindices[i].tolist())

        else:
            if np.isin(vi0,hvindices) and np.isin(vi1,hvindices):
                heindices.append(oeindices[i].tolist())

            elif np.isin(vi0,bvindices) and np.isin(vi1,bvindices):
                beindices.append(oeindices[i].tolist())

            else:
                omeindices.append(oeindices[i].tolist())

    ceindices = np.array(ceindices)
    heindices = np.array(heindices)
    beindices = np.array(beindices)
    omeindices = np.array(omeindices)

    # 3.5 inner mixed edges with one inner and one outer vertex, all mixed edges
    imeindices = eindices[np.nonzero(np.where(np.sum(np.isin(eindices,ovindices).astype(int), axis=1)==1, 1,0))[0]]
    meindices = np.vstack((omeindices,imeindices))

    # 3.6 inner edges
    ieindices = eindices[np.nonzero(np.prod(np.isin(eindices, ivindices).astype(int), axis=1))[0]]

    # X. Store all vertices and edges in dictMesh
    # X.1 all vertices indices
    dictMesh["hvindices"] = hvindices
    dictMesh["bvindices"] = bvindices
    dictMesh["ivindices"] = ivindices

    #  edges and all edges indices
    dictMesh["edges"] = edges
    dictMesh["eindices"] = eindices
    dictMesh["oeindices"] = oeindices
    dictMesh["heindices"] = heindices
    dictMesh["beindices"] = beindices
    dictMesh["ceindices"] = ceindices
    dictMesh["meindices"] = meindices
    dictMesh["ieindices"] = ieindices

    return dictMesh

def quadric_coefficients(dictData,dictMesh):
    # 0. initialize output dictionary for function and quadrices arrays
    dictQuadrics = dict()

    sindices = dictData["sindices"]
    simplices = dictData["simplices"]
    ysimplices = dictData["ysimplices"]

    vindices = dictData["vindices"]
    vertices = dictData["vertices"]
    yvertices = dictData["yvertices"]

    eindices = dictMesh["eindices"]
    edges = dictMesh["edges"]

    triangulation = dictData["triangulation"]
    dim = dictData["dim"]

    A_s = np.empty((len(sindices),dim[0]+1,dim[0]+1))
    b_s = np.empty((len(sindices),dim[0]+1))
    c_s = np.empty((len(sindices)))

    A_v = np.empty((len(vindices),dim[0]+1,dim[0]+1))
    b_v = np.empty((len(vindices),dim[0]+1))
    c_v = np.empty((len(vindices)))
    vlist = np.zeros(len(vindices))

    A_e = np.empty((len(eindices),dim[0]+1,dim[0]+1))
    b_e = np.empty((len(eindices),dim[0]+1))
    c_e = np.empty((len(eindices)))

    # 1. calculate quadrics  for simlices
    for i in range(len(simplices)):
        A_s[i,:,:], b_s[i,:], c_s[i] = quadrics_Abc(simplices[i],ysimplices[i],dim)

    # 2. calculate quadrics for vertices based on quadrics for simplices
    i = 0
    for sindex in sindices:
        A_v[sindex,:,:] += A_s[i]
        b_v[sindex,:] += b_s[i]
        c_v[sindex] += c_s[i]

        vlist[sindex] += 1
        i += 1

    # for i in range(len(vlist)):
    #     A_v[i] /= vlist[i]
    #     b_v[i] /= vlist[i]
    #     c_v[i] /= vlist[i]

    # 3. calculate quadrics for edges based on quadrics for simplices
    i = 0
    for eindex in eindices:
        A_e[i,:,:] = np.sum(A_v[eindex])
        b_e[i,:] = np.sum(b_v[eindex])
        c_e[i] = np.sum(c_v[eindex])

        i += 1

    return A_e, b_e, c_e

def contract_edge(dictData,dictMesh,A_e,b_e,c_e):
    #1. Find indices of edge types in edge list
    vertices = dictData["vertices"]
    yvertices = dictData["yvertices"]

    edges = dictMesh["edges"]
    eindices = dictMesh["eindices"]
    heindices = dictMesh["heindices"]
    beindices = dictMesh["beindices"]
    ceindices = dictMesh["ceindices"]
    meindices = dictMesh["meindices"]
    ieindices = dictMesh["ieindices"]

    hvindices = dictMesh["hvindices"]
    bvindices = dictMesh["bvindices"]

    # 1.1 hull edges
    he1 = np.array(list(map(tuple, eindices)), np.dtype('int,int'))
    he2 = np.array(list(map(tuple, heindices)), np.dtype('int,int'))
    hes = np.nonzero(np.isin(he1,he2))[0]

    # 1.2 boundary edges
    be1 = np.array(list(map(tuple, eindices)), np.dtype('int,int'))
    be2 = np.array(list(map(tuple, beindices)), np.dtype('int,int'))
    bes = np.nonzero(np.isin(be1,be2))[0]

    # 1.3 constitutional edges
    ce1 = np.array(list(map(tuple, eindices)), np.dtype('int,int'))
    ce2 = np.array(list(map(tuple, ceindices)), np.dtype('int,int'))
    ces = np.nonzero(np.isin(ce1,ce2))[0]

    # 1.4 mixed edges
    me1 = np.array(list(map(tuple, eindices)), np.dtype('int,int'))
    me2 = np.array(list(map(tuple, meindices)), np.dtype('int,int'))
    mes = np.nonzero(np.isin(me1,me2))[0]

    # 1.5 inner edges
    ie1 = np.array(list(map(tuple, eindices)), np.dtype('int,int'))
    ie2 = np.array(list(map(tuple, ieindices)), np.dtype('int,int'))
    ies = np.nonzero(np.isin(ie1,ie2))[0]

    # 2. create dictionary of new vertices
    nvertices = dict()
    nyvertices = dict()

    for e in range(len(eindices)):
        # 2.1 new vertices for hull edges
        if e in hes:
            continue # hull edges are not contractable

        # 2.2 vertices for boundary edges
        if e in bes:
            nvertices[e] = np.linspace(vertices[eindices[e]][0], vertices[eindices[e]][1], num = 5) # five points between vertices of edge
            nyvertices[e] = np.linspace(yvertices[eindices[e]][0], yvertices[eindices[e]][1], num = 5) # five points between vertices of edge
            continue

        # 2.3 constitutional edges
        if e in ces:
            continue # constitutional edges are not contractable

        # 2.4 new vertices for mixed edges
        elif e in mes:
            if eindices[e][0] in hvindices:
                nvertices[e] = np.array([vertices[eindices[e][0]]])
                nyvertices[e] = np.array([yvertices[eindices[e][0]]])
                continue

            elif eindices[e][1] in hvindices:
                nvertices[e] = np.array([vertices[eindices[e][1]]])
                nyvertices[e] = np.array([yvertices[eindices[e][1]]])
                continue

            elif eindices[e][0] in bvindices:
                nvertices[e] = np.array([vertices[eindices[e][0]]])
                nyvertices[e] = np.array([yvertices[eindices[e][0]]])
                continue

            elif eindices[e][1] in bvindices:
                nvertices[e] = np.array([vertices[eindices[e][1]]])
                nyvertices[e] = np.array([yvertices[eindices[e][1]]])
                continue

            else:
                continue

        # 2.5 new vertices for inner edges
        else:
            if np.linalg.det(A_e[e]) < 1e-3:
                nvertices[e] = np.linspace(vertices[eindices[e]][0], vertices[eindices[e]][1], num = 5) # five points between vertices of edge
                nyvertices[e] = np.linspace(yvertices[eindices[e]][0], yvertices[eindices[e]][1], num=5)  # five points between vertices of edge
                continue
            else:
                nyvertices[e] = np.array([-np.dot(np.linalg.inv(A_e[e]),b_e[e])])
                nvertices[e] = nyvertices[e][:-1]
                continue

    # 3. Calculate quadric errors for each edge contraction
    qerrors = dict()
    edict = dict()
    for e in nvertices.keys():
        q = np.empty(nvertices[e].shape[0])
        nv = nyvertices[e]

        for i in range(len(nv)):
            q[i] = np.dot(nv[i].T,np.dot(A_e[e],nv[i])) + 2*np.dot(b_e[e].T,nv[i]) + c_e[e]
            print("xAx",np.dot(nv[i].T,np.dot(A_e[e],nv[i])),"2bx",2*np.dot(b_e[e].T,nv[i]),"c",c_e[e])
        if np.isnan(q[0]):
            continue

        # print("q",q,"nvy",nyvertices[e],"ovy",yvertices[eindices[e]])

        qerrors[e] = np.min(q)
        nvertices[e] = nvertices[e][(np.where(np.min(q) == q)[0][0])]
        nyvertices[e] = nyvertices[e][(np.where(np.min(q) == q)[0][0])]
        edict[e] = eindices[e]

    # 4. Find minimum quadric error
    minq = min(qerrors.values())
    minkey = list(qerrors.keys())[list(qerrors.values()).index(minq)]

    vertex_new = nvertices[minkey]
    yvertex_new = nyvertices[minkey]
    eindex_old = edict[minkey]

    # 5. Calculate new prediction for new point
    nvsindex = Delaunay.find_simplex(dictData["triangulation"],np.array([vertex_new]))
    nvsimplex = dictData["vertices"][dictData["sindices"][nvsindex[0]]]
    nvvindices = dictData["sindices"][nvsindex[0]]
    bcc = barycentric_coordinates(nvsimplex,vertex_new)

    prediction_new = np.sum(np.multiply(dictData["prediction"][nvvindices][:,0], bcc))

    return vertex_new, yvertex_new, eindex_old, prediction_new

def calculate_error(dictData, dictReduced, old_vertices, old_attributes):
    # 1. calculate error for Y for each new vertex
    ovsindices = Delaunay.find_simplex(dictReduced["triangulation"],old_vertices)
    ovsimplices = dictReduced["vertices"][dictReduced["sindices"][ovsindices[:]]]
    ovysimplices = dictReduced["yvertices"][dictReduced["sindices"][ovsindices[:]]]
    ovvindices = dictReduced["sindices"][ovsindices[:]]

    bccs = np.empty((len(ovsindices),dictData["dim"][0]+1))

    for i in range(len(ovsindices)):
        bccs[i,:] = barycentric_coordinates(ovsimplices[i],old_vertices[i])

    calculated_attributes = np.sum(np.multiply(dictReduced["prediction"][ovvindices][:,:,0], bccs), axis=1)

    # 2. Calculate Root Mean Square Error and normalized Root Mean Square Error
    rmsqr = np.sqrt(np.divide(np.sum(np.square(np.subtract(old_attributes.T[0],calculated_attributes))),len(calculated_attributes)))

    rmsqrn = np.divide(rmsqr, np.sqrt(np.square(max(dictData["Y"])[0] - min(dictData["Y"])[0])))

    return rmsqr, rmsqrn