clear; clc;
addpath("../simulations")

% read MCS data
cID = 8;  % select configuration
M = 100;
red = [2,5,6,8];
N = 100;

for d =1:M
    load(sprintf("run%d_C%d_GPR",d,cID));
    Xs = X(1,:);
    clear X y yci ypred ysd T Ti To
    
    Tti = readtable(sprintf("trun%d_C%di.csv",d,cID));
    Tto = readtable(sprintf("trun%d_C%do.csv",d,cID));
    
    Tt = [Tti Tto];
    X = Tt{:,Tti.Properties.VariableNames}; % inputs
    y = Tt{:,'NetEnthalpy'}; % objective
    
    Xx = ones(length(X),length(Xs));
    Xx = Xx .* Xs;
    Xx(:,red) = X;
    
    ypred = predict(objGPR,Xx);
    Y = [y ypred];
    
%     Y = array2table(Y,'VariableNames',{'y','ypred'});
%     writetable(Y,sprintf("y%d_C%di.csv",d,cID));
    
    R2(d) = corr(Y(:,1),Y(:,2)).^2
    
    RMSE(d) = sqrt(mean((y - ypred).^2));
    
end