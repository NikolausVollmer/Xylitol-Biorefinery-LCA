function [A,E] = pyrolysis_parameters()
%PARAMETERS FOR THE PYROLYSIS MODEL FOR LIGNOCELLULOSIC BIOMASS PYROLYSIS 
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 04.03.2021

%% Frequency factors - 1/s
A = zeros(28,1);

A(1) = 1.5e14;
A(2) = 2.5e6;
A(3) = 3.3;
A(4) = 9e7;

A(5)= 1e10;
A(6) = 1.25e11;
A(7) = 1.25e11;
A(8) = 16;
A(9) = 3e-3;
A(10) = 7e9;

A(11) = 6.7e12;
A(12) = 3.3e8;
A(13) = 1e11;
A(14) = 1e4;
A(15) = 1.5e8;
A(16) = 4;
A(17) = 8.3e-2;
A(18) = 1.5e9;

A(19) = 1e6;
A(20) = 5e12;
A(21) = 2e12;
A(22) = 6e10;
A(23) = 1e11;
A(24) = 1e11;
A(25) = 1e11;
A(26) = 1.5e12;
A(27) = 1e9;
A(28) = 1e8;

A(29) = 2.5e6;
A(30) = 3.3;
A(31) = 7e9;

%% Activation energies - kcal/kmol
E = zeros(28,1);

E(1) = 47;
E(2) = 19.1;
E(3) = 10;
E(4) = 31;

E(5) = 31;
E(6) = 31.4;
E(7) = 30;
E(8) = 12.9;
E(9) = 3.6;
E(10) = 30.5;

E(11) = 37.5;
E(12) = 25.5;
E(13) = 37.2;
E(14) = 24.8;
E(15) = 30;
E(16) = 12;
E(17) = 8;
E(18) = 31.5;

E(19) = 24.5;
E(20) = 52.5;
E(21) = 50;
E(22) = 50;
E(23) = 52;
E(24) = 53;
E(25) = 54;
E(26) = 55;
E(27) = 59;
E(28) = 70;

E(29) = 19.1;
E(30) = 10;
E(31) = 30.5;

E = E .* 4.184; % conversion from kcal to kJ/mol
end

