function dydt = pyrolysis_kinetics(t,y,par,stats)
%PYROLYSIS KINETICS FOR LIGNOCELLULOSIC BIOMASS PYROLYSIS 
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 04.03.2021

R = 8.314e-3; % kJ/mol/K
Tmax = 273.15 + stats(1);
dT = stats(2);
T = y(54);

[A,E] = pyrolysis_parameters();

%% Reaction equations
% 1 - Cellulose to Cellulose-A
% 2 - Cellulose-A degradation
% 3 - Cellulose-A to levoglucosan
% 4 - Cellulose degradation

% 5 - Softwood hemicellulose split (GMSW)
% 6 - Hardwood hemicellulose split (XYHW)
% 7 - Grass hemicellulose split (XYGR)
% 8 - Hemicellulose-1 to furfural
% 9 - Hemicellulose-1 direct degradation
% 10 - Hemicellulose-2 to furfural

% 11 - LigH to LigOH
% 12 - LigO to LigOH
% 13 - LigC to LigCC
% 14 - LigCC degradation
% 15 - LigOH degradation
% 16 - Lig to vanillin
% 17 - Lig slow degradation
% 18 - Lig fast degradation

% 19 - GCO2 to CO2
% 20 - GCO to CO
% 21 - GCH3OH to MeOH
% 22 - GCOH2-loose to CO and others
% 23 - GC2H6 to C2H6
% 24 - GCH4  to CH4
% 25 - GC2H4  to C2H4
% 26 - GPhenol to Phenol
% 27 - GCOH2-stiff to CO and others
% 28 - GH2 to H2

% 29 - Glucose degradation
% 30 - Glucose to levoglucosan
% 31 - Xylose to furfural

r = zeros(25,1);

r(1) = A(1) * exp(-E(1)/(R*T)) * y(1);
r(2) = A(2) * exp(-E(2)/(R*T)) * y(2);
r(3) = A(3) * T * exp(-E(3)/(R*T)) *y(2);
r(4) = A(4) * exp(-E(4)/(R*T)) * y(1);

r(5) = A(5) * exp(-E(5)/(R*T)) * y(3);
r(6) = A(6) * exp(-E(6)/(R*T)) * y(4);
r(7) = A(7) * exp(-E(7)/(R*T)) * y(5);
r(8) = A(8) * T * exp(-E(8)/(R*T)) * y(6);
r(9) = A(9) * T * exp(-E(9)/(R*T)) * y(6);
r(10) = A(10) * exp(-E(10)/(R*T)) * y(7);

r(11) = A(11) * exp(-E(11)/(R*T)) * y(10);
r(12) = A(12) * exp(-E(12)/(R*T)) * y(9);
r(13) = A(13) * exp(-E(13)/(R*T)) * y(8);
r(14) = A(14) * exp(-E(14)/(R*T)) * y(11);
r(15) = A(15) * exp(-E(15)/(R*T)) * y(12);
r(16) = A(16) * T * exp(-E(16)/(R*T)) * y(13);
r(17) = A(17) * T * exp(-E(17)/(R*T)) * y(13);
r(18) = A(18) * exp(-E(18)/(R*T)) * y(13);

r(19) = A(19) * exp(-E(19)/(R*T)) * y(43);
r(20) = A(20) * exp(-E(20)/(R*T)) * y(42);
r(21) = A(21) * exp(-E(21)/(R*T)) * y(49);
r(22) = A(22) * exp(-E(22)/(R*T)) * y(44);
r(23) = A(23) * exp(-E(23)/(R*T)) * y(46);
r(24) = A(24) * exp(-E(24)/(R*T)) * y(48);
r(25) = A(25) * exp(-E(25)/(R*T)) * y(47);
r(26) = A(26) * exp(-E(26)/(R*T)) * y(50);
r(27) = A(27) * exp(-E(27)/(R*T)) * y(45);
r(28) = A(28) * exp(-E(28)/(R*T)) * y(41);

r(29) = A(29) * exp(-E(29)/(R*T)) * y(52);
r(30) = A(30) * T * exp(-E(30)/(R*T)) *y(52);
r(31) = A(31) * exp(-E(31)/(R*T)) * y(53);


%% Stoichiometric matrix & component balances
% 1 - Cellulose - glucan / C6H10O5 monomer
% 2 - Cellulose-A

% 3 - Softwood hemicellulose (GMSW) - glucomannan / C5H8O4 monomer
% 4 - Hardwood hemicellulose (XYHW) - xylan / C5H8O4 monomer
% 5 - Grass hemicellulose (XYGR) - xylan / C5H8O4 monomer
% 6 - Hemicellulose-1
% 7 - Hemicellulose-2

% 8 - LigC - p-coumaryl alcohol unit / C15H14O4 monomer
% 9 - LigO - sinapyl alcohol unit / C20H22O10 dimer
% 10 - LigH - sinapyl alcohol unit / C22H28O9 dimer
% 11 - LigCC
% 12 - LigOH
% 13 - Lig

% 14 - 3-Hydroxypropanal
% 15 - Proprionaldehyd
% 16 - Propanedial
% 17 - Hydroxyacetaldehyde
% 18 - Glyoxal
% 19 - Acetaldehyde
% 20 - Acetic acid
% 21 - Ethanol
% 22 - Formaldehyde
% 23 - Formic acid
% 24 - Methanol

% 25 - Xylosan
% 26 - Levoglucosan
% 27 - Furfural
% 28 - 5-HMF

% 29 - Anisol
% 30 - Cresol
% 31 - Phenol
% 32 - Vanillin
% 33 - Macromolecular Lignin (HMWL)

% 34 - C2H6
% 35 - C2H4
% 36 - CH4
% 37 - Carbon monooxide
% 38 - Carbon dioxide
% 39 - Hydrogen
% 40 - Water

% 41 - GH2
% 42 - GCO
% 43 - GCO2
% 44 - GCOH2-loose
% 45 - GCOH2-stiff
% 46 - GC2H6
% 47 - GC2H4
% 48 - GCH4
% 49 - GCH3OH
% 50 - GPhenol

% 51 - Char
% 52 - Glucose
% 53 - Xylose


S = zeros(31,53);

S(1,1) = -1; S(1,2) = 1;
S(2,2) = -1; S(2,14) = 0.05; S(2,15) = 0.35; S(2,17) = 0.4; S(2,18) = 0.03; S(2,19) = 0.17; S(2,22) = 0.15; S(2,23) = 0.02; S(2,24) = 0.2; S(2,28) = 0.25; S(2,36) = 0.05; S(2,37) = 0.49; S(2,38) = 0.43; S(2,39) = 0.13; S(2,40) = 0.93; S(2,41) = 0.05; S(2,42) = 0.05; S(2,44) = 0.05; S(2,51) = 0.66;
S(3,2) = -1; S(3,26) = 1;
S(4,1) = -1; S(4,39) = 0.125; S(4,40) = 4.45; S(4,41) = 0.125; S(4,42) = 0.25; S(4,44) = 0.18; S(4,45) = 0.12; S(4,51) = 5.45;

S(5,3) = -1; S(5,6) = 0.7; S(5,7) = 0.3;
S(6,4) = -1; S(6,6) = 0.35; S(6,7) = 0.65;
S(7,5) = -1; S(7,6) = 0.12; S(7,7) = 0.88;
S(8,6) = -1; S(8,14) = 0.06; S(8,18) = 0.1; S(8,25) = 0.25; S(8,26) = 0.25; S(8,27) = 0.16; S(8,28) = 0.13; S(8,36) = 0.1; S(8,38) = 0.09; S(8,39) = 0.02; S(8,40) = 0.54; S(8,51) = 0.1;
S(9,6) = -1; S(9,22) = 0.4; S(9,23) = 0.05; S(9,35) = 0.1; S(9,36) = 0.3; S(9,37) = 0.49; S(9,38) = 0.39; S(9,39) = 0.1; S(9,40) = 0.4; S(9,41) = 0.05; S(9,42) = 0.01; S(9,43) = 0.51; S(9,44) = 0.43; S(9,45) = 0.37; S(9,46) = 0.2; S(9,47) = 0.075; S(9,48) = 0.325; S(9,51) = 0.975;
S(10,7) = -1; S(10,17) = 0.035; S(10,20) = 0.105; S(10,21) = 0.049; S(10,23) = 0.0175; S(10,27) = 0.145; S(10,36) = 0.1895; S(10,37) = 0.3; S(10,38) = 0.5125; S(10,39) = 0.5505; S(10,40) = 0.056; S(10,41) = 0.21; S(10,43) = 0.45; S(10,44) = 0.18; S(10,45) = 0.78; S(10,46) = 0.2; S(10,47) = 0.1; S(10,48) = 0.05; S(10,49) = 0.105; S(10,51) = 0.7125;

S(11,10) = -1; S(11,12) = 1; S(11,15) = 0.5; S(11,17) = 0.2; S(11,34) = 0.1; S(11,35) = 0.4; S(11,37) = 0.1;
S(12,9) = -1; S(12,12) = 1; S(12,38) = 1;
S(13,8) = -1; S(13,11) = 0.35; S(13,22) = 0.22; S(13,29) = 0.1; S(13,32) = 0.1; S(13,35) = 0.27; S(13,37) = 0.21; S(13,38) = 0.1; S(13,40) = 1; S(13,41) = 0.1; S(13,44) = 0.17; S(13,45) = 0.4; S(13,46) = 0.2; S(13,48) = 0.36; S(13,51) = 5.85;
S(14,11) = -1; S(14,17) = 0.35; S(14,29) = 0.15; S(14,30) = 0.15; S(14,32) = 0.25; S(14,34) = 0.4; S(14,35) = 0.3; S(14,36) = 0.45; S(14,37) = 1.15; S(14,39) = 0.7; S(14,40) = 0.7; S(14,42) = 0.4; S(14,51) = 6.8;
S(15,12) = -1; S(15,13) = 0.9; S(15,15) = 0.1; S(15,23) = 0.05; S(15,24) = 0.6; S(15,33) = 0.025; S(15,36) = 0.1; S(15,37) = 0.65; S(15,38) = 0.05; S(15,40) = 1; S(15,42) = 0.6; S(15,44) = 0.45; S(15,45) = 0.4; S(15,46) = 0.15; S(15,47) = 0.1; S(15,48) = 0.25; S(15,49) = 0.3; S(15,51) = 4.25;
S(16,13) = -1; S(16,19) = 0.3; S(16,29) = 0.1; S(16,32) = 1; S(16,35) = 0.5; S(16,37) = 0.6; S(16,51) = 0.1;
S(17,13) = -1; S(17,22) = 0.4; S(17,36) = 0.2; S(17,37) = 0.3; S(17,38) = 0.1; S(17,40) = 0.6; S(17,41) = 0.1; S(17,42) = 0.2; S(17,44) = 1.25; S(17,45) = 0.65; S(17,47) = 0.5; S(17,48) = 0.4; S(17,49) = 0.4; S(17,51) = 6.1;
S(18,13) = -1; S(18,22) = 0.4; S(18,24) = 0.4; S(18,34) = 0.5; S(18,35) = 0.75; S(18,36) = 0.6; S(18,37) = 2.6; S(18,40) = 0.6; S(18,51) = 4.5;

S(19,38) = 1; S(19,43) = -1;
S(20,37) = 1; S(20,42) = -1;
S(21,24) = 1; S(21,49) = -1;
S(22,37) = 0.2; S(22,39) = 0.2; S(22,40) = 0.8; S(22,44) = -1; S(22,51) = 0.8;
S(23,34) = 1; S(23,46) = -1;
S(24,36) = 1; S(24,48) = -1;
S(25,35) = 1; S(25,47) = -1;
S(26,31) = 1; S(26,50) = -1;
S(27,37) = 0.8; S(27,39) = 0.8; S(27,40) = 0.2; S(27,45) = -1; S(27,51) = 0.2;
S(28,39) = 1; S(28,41) = -1;

S(29,14) = 0.05; S(29,15) = 0.35; S(29,17) = 0.4; S(29,18) = 0.03; S(29,19) = 0.17; S(29,22) = 0.15; S(29,23) = 0.02; S(29,24) = 0.2; S(29,28) = 0.25; S(29,36) = 0.05; S(29,37) = 0.49; S(29,38) = 0.43; S(29,39) = 0.13; S(29,40) = 0.93; S(29,41) = 0.05; S(29,42) = 0.05; S(29,44) = 0.05; S(29,51) = 0.66; S(29,52) = -1;
S(30,26) = 1; S(30,52) = -1;
S(31,17) = 0.035; S(31,20) = 0.105; S(31,21) = 0.049; S(31,23) = 0.0175; S(31,27) = 0.145; S(31,36) = 0.1895; S(31,37) = 0.3; S(31,38) = 0.5125; S(31,39) = 0.5505; S(31,40) = 0.056; S(31,41) = 0.21; S(31,43) = 0.45; S(31,44) = 0.18; S(31,45) = 0.78; S(31,46) = 0.2; S(31,47) = 0.1; S(31,48) = 0.05; S(31,49) = 0.105; S(31,51) = 0.7125; S(31,53) = -1;


dydt = S'*r;

% Temperature
if y(54) >= Tmax
    dydt(54,1) = 0;
else
    dydt(54,1) = dT/60;
end
