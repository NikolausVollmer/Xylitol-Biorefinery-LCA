%Method of moment function defining the model
function dxdt = crystallization_succ_mom(t, x, par_solvent, par_Sac, par_design, stats)

%% STATS
m_H2O = stats(1);      % Mass of H2O - [kg]
F_AS = stats(2);       % Flow rate of antisolvent - [kg/s]
V0 = stats(3);         % Initial Volume of system - [m3]
m0_Sac = stats(4);
N = stats(5);          % impeller speed - [rpm]
m0_cryst = stats(6);   % seed mass - [kg]
%% PARAMETERS
% Solvent
rho_L = par_solvent(1);     % density of water - [kg/m3]
rho_AS = par_solvent(2);    % density of the antisolvent - [kg/m3]
Mw_L = par_solvent(3);      % molar mass of the liquid - [kg/m3]
Mw_AS = par_solvent(4);     % molar mass of the antisolvent - [kg/m3]
Cp_L = par_solvent(5);      % heat capacity of water - [kg/m3]
Cp_AS = par_solvent(6);     % heat capacity of the antisolvent - [kg/m3]

% Succinic Acid
rho_Sac = par_Sac(1);
DH_fus_Sac = par_Sac(2);
ka = par_Sac(3);
kv = par_Sac(4);
Mw_Sac = par_Sac(5);
L0 = par_Sac(6);

% Design
U = par_design(1);         % Heat transfer coefficient - [W/m2/degC]
T0_C = par_design(2);      % Initial coolant temperature - [degC]
A = par_design(3);         % Heat transfer area - [m2]
F_C = par_design(4);       % Coolant flowrate - [kg/s]
V_j = par_design(5);       % Cooling jacket volume - [m3]

%Defining change in solvent properties                   
w_AS = (x(8) - m_H2O) / x(8);                            % Weight fraction of antisolvent in solvent - [-]
rho_Sol = 1 / (w_AS/rho_AS + (1-w_AS)/rho_L);            % Density of solvent - [kg/m3]
X_AS = (x(8)/rho_Sol - m_H2O/rho_L) / (x(8,1)/rho_Sol);  % Volume fraction of antisolvent - [-]
Mw_Sol = Mw_L * (1-X_AS) + Mw_AS * X_AS;                 % Molecular weight of solvent - [g/mol]
Cp_Sol = 0;


%% Solubility
%The regression was done in matlab using polynomial regression to the 3
%degree Csat vs 1/T and w_a

%Regression parameters
p1 =   9.504e-07; %  (7.674e-08, 1.824e-06)
p2 =    4.41e-06; %  (-7.7e-05, 8.582e-05)
p3 =    0.001628; %  (-0.0008373, 0.004093)
p4 =     0.02543; %  (0.00122, 0.04963)

%Solubility
T = x(6); % Temperature in crystallizer - [degC]

Csat = p1*T^3 + p2*T^2 + p3*T + p4;


%%Supersaturation
Creal = x(5) / x(8); % kg Suc (L) / kg solvent
Mt = m0_cryst + (m0_Sac - x(5)) / x(8); % kg Suc (S) / kg solvent

if Creal <= Csat
    Delta_C = 0;
else
    Delta_C = Creal - Csat;
end

%Kinetics - Qiu,Rasmuson 1994, Tbl. 5, Obj as Eq. 9, P as 95%
if Creal <= Csat
    G = 0;
    B = 0;
else 
    G = 0.657e-6 * Delta_C^1.21 * N^0.807;
    B = 1.29e6 * Delta_C^2.44 * Mt^0.667 * N^1.37;
end


%% Method of Moments
% according to work from Zoltan Nagy, 2008, ESCAPE18 Proceedings, "A
% population balance model approach for crystallization product engineering
% via distribution shaping control"

% x(1) - mu0(0)
% x(2) - mu1(0) 
% x(3) - mu2(0)
% x(4) - mu3(0) 
% x(5) - mass balance succinic acid in liquid phase, m_Sac - [kg] 
% x(6) - Temperature in liquid phase, T - [degC]
% x(7) - Temperature in cooling jacket, T - [degC]
% x(8) - mass balance solvent [kg]
% x(9) - mass balance succinic acid in solid phase, m_Sac(s) - [kg]

dxdt(1,1) = B;                                       % [#/m^3/s]
dxdt(2,1) = G*x(1) + B * L0;                         % [m/m^3/s]
dxdt(3,1) = 2*G*x(2) + B * L0^2;                       % [m^2/m^3/s]
dxdt(4,1) = 3*G*x(3) + B * L0^3;                       % [m^3/m^3/s]

dxdt(5,1) = - rho_Sac * kv * dxdt(4,1) / rho_Sol * x(8);       % [kg Xyo/s]

dxdt(6,1) = ((DH_fus_Sac/Mw_Sac) * rho_Sac/rho_Sol * kv * (3*G*x(3) + B*L0^3) - ...
              U*A*(x(6)-x(7)))/(x(8)*((1-w_AS)*Cp_L + Cp_AS*w_AS));    % [degC/s]

dxdt(7,1) = (F_C*Cp_L*(T0_C - x(7)) + U*A*(x(6) - x(7)))/(V_j*rho_L*Cp_L); % [degC/s]

dxdt(8,1) = F_AS;                                      % [kg/s]

end