function dydt = fermentation_xylitol_kinetics(t,y,par,stats)
%% KINETICS FOR FED-BATCH

%% STATS
C_Glu_0 = stats(1);
C_Xyl_0 = stats(2);
F_in = stats(3);
time = stats(4);
tfstart = stats(5);
tfend = stats(6);

f_in = feed(F_in, t, tfstart, tfend, time);

%% Concentrations
C_Glu = y(1);
C_Xyl = y(2);
C_X = y(3);
C_Xyo = y(4);

V = y(5); % Broth volume

%% Parameters
q_s_max_Glu = par(1);
q_s_max_Xyl = par(2);
q_s_max_Xyo = par(3);

K_Glu = par(4);
K_Xyl = par(5);
K_Xyo = par(6);

K_I_Glu = par(7);
K_I_Xyl = par(8);

a_Glu = par(9);
ms_Glu = par(10);

a_Xyl = par(11);
b_Xyl = par(12);
ms_Xyl = par(13);

a_Xyo = par(14);
ms_Xyo = par(15);

alpha = par(16);
beta = par(17);

%% Rates
% substrate uptake rate
q_s_Glu = q_s_max_Glu * (C_Glu/(K_Glu + C_Glu));
q_s_Xyl = q_s_max_Xyl * (C_Xyl/(K_Xyl + C_Xyl)) * (1/(1 + C_Glu/K_I_Glu));
q_s_Xyo = q_s_max_Xyo * (C_Xyo/(K_Xyo + C_Xyo)) * (1/(1 + C_Xyl/K_I_Xyl));

% growth rate 
mu_Glu = q_s_Glu/a_Glu - ms_Glu/a_Glu; % on glucose (Herbert-Pirt)
mu_Xyl = (q_s_Xyl - beta*b_Xyl - ms_Xyl) / (a_Xyl + alpha * b_Xyl); % on xylose (Herbert-Pirt) with substrate consumption rate
mu_Xyo = q_s_Xyo/a_Xyo - ms_Xyo/a_Xyo; % on xylitol (Herbert-Pirt)

mu = mu_Glu + mu_Xyl * (1/(1 + C_Glu/K_I_Glu)) + mu_Xyo * (1/(1 + C_Xyl/K_I_Xyl)); % combined growth rate

% q_p(mu) relation / production rate
q_p_Xyo = (alpha * mu_Xyl + beta) * (1/(1 + K_I_Xyl/C_Xyl));

q_Xyo = q_p_Xyo - q_s_Xyo; % product rate both for consumption and production

%% Balances

% 1 - Glucose (Glu)
% 2 - Xylose (Xyl)
% 3 - Biomass (X)
% 4 - Xylitol (XyH)

dydt(1,1) = f_in/V * (C_Glu_0 - C_Glu) - q_s_Glu * C_X;
dydt(2,1) = f_in/V * (C_Xyl_0 - C_Xyl) - q_s_Xyl * C_X;
dydt(3,1) = (mu - f_in/V) * C_X;
dydt(4,1) = q_Xyo * C_X - f_in/V * C_Xyo;
dydt(5,1) = f_in; % Change in Volume

end

function f_in = feed(F_in, t, tfstart, tfend, time)

if t < tfstart*time
    f_in = 0;
    
elseif tfstart * time < t < tfend * time
    f_in = F_in;
    
elseif t > tfend * time
    f_in = 0;
    
end

end


