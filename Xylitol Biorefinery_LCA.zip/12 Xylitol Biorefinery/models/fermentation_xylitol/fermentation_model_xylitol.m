function [m_broth, c_out, mf, hf, design] = fermentation_model_xylitol(m,c_in,stats)
%UNTITLED9 Summary of this function goes here
%   Detailed explanation goes here

time = stats(1);
c_inoc = stats(2);
Vfrac = stats(3);
tfstart = stats(4);
tfend = stats(5);

c_inoc = 3/Vfrac;

% Parameters
par = fermentation_xylitol_parameters();

rho_substrate = 1.02;  % substrate density in kg/L, assumed constant over time
rho_broth = 1.05;      % broth density in kg/L, assumed constant over time

% Time
% Time of residence
tlength = ceil(time/24)*100;
tspan = linspace(0,time,tlength);

% State variables
% other state variables are taken out of the vector
V_0 = Vfrac * m / rho_substrate; % in L
% V_1 = Vfrac2 * m / rho_substrate - V_0; % in L
% V_2 = m / rho_substrate - V_1 - V_0; % in L
V_total = m / rho_substrate; % in L

F_in = feed_rate(V_0, V_total, time, tfstart, tfend);

% Feed conditions
m_in = m;
c_Glu0 = c_in(4) * 10 * rho_substrate;
c_Xyl0 = c_in(2) * 10 * rho_substrate;
c_Xyo0 = c_in(18) * 10 * rho_substrate;

%% Fermentation
% Initial conditions
x0(1) = c_Glu0;  % Initial concentration of Glucose in g/L hydrolyzate
x0(2) = c_Xyl0;  % Initial concentration of Xylose in g/L hydrolyzate
x0(3) = c_inoc;  % Initial concentration of Biomass (Inoculum) in g/L hydrolyzate
x0(4) = c_Xyo0;  % Initial concentration of Xylitol in g/L hydrolyzate
x0(5) = V_0;     % Initial volume in L

% Stats for fed-batch fermentation
stats(1) = c_in(4) * 10 * rho_substrate; % Initial Concentration of Glucose
stats(2) = c_in(2) * 10 * rho_substrate; % Initial Concentration of Xylose
stats(3) = F_in;
stats(4) = time;
stats(5) = tfstart;
stats(6) = tfend;

% Black-box kinetics for substrate, biomass and product
options = odeset('RelTol',1e-7,'AbsTol',1e-8,'NonNegative',[1:4]);
[~,y] = ode45(@fermentation_xylitol_kinetics,tspan,x0,options,par,stats);

% figure
% hold on
% plot(tspan,y(:,1))
% plot(tspan,y(:,2))
% plot(tspan,y(:,3))
% plot(tspan,y(:,4))

% Rates from BBM and calculated rates via stoichiometry
[q_Glu, q_Xyl, mu, q_Xyo, q_O2, q_NH4, q_CO2, q_H2O, q_Proton, q_Heat, reg] = Process_Reaction(y,par);
    
% Outflows
[m_broth, c_out, M_air_in, M_air_out, M_nitro, M_titr, M_evap, M_biomass, H_ext] = Outflows(m_in, c_in, y, time, tlength, q_Glu, q_Xyl, mu, q_Xyo, q_O2, q_NH4, q_CO2, q_H2O, q_Proton, q_Heat, reg, rho_broth);

% Sizing
V_reactor = Sizing(m_broth, rho_broth, time);

% Costing
FCI = costing_fermentation_xylitol(m_broth);


% Function output
mf(1) = M_air_in;
mf(2) = M_nitro;
mf(3) = M_titr;
mf(4) = M_air_out;
mf(5) = M_evap;
mf(6) = M_biomass;

hf = H_ext;

design = [V_reactor, FCI];

end

%% Feed rate
function F_in = feed_rate(V_0, V_total, time, tfstart, tfend)

if tfend > tfstart
    F_in = (V_total - V_0) / ((tfend - tfstart)* time); % in L/h
else
    F_in = 0;
end

end

%% Process Reaction
function [q_Glu, q_Xyl, mu, q_Xyo, q_O2, q_NH4, q_CO2, q_H2O, q_Proton, q_Heat, reg] = Process_Reaction(y,par)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

%% Standard Enthalpies of Fusion
HR_Glu = -1273.48; % kJ/mol - Pro/II
HR_Xyl = -856.87;  % kJ/mol - Pro/II
HR_Xyo = -1219.30; % kJ/mol - Pro/II
HR_NH4 = -132.8;   % kJ/mol - Pro/II (for ammonium ion)
HR_O2 = 0;         % kJ/mol - Pro/II
HR_X = -119.83;    % kJ/mol - paper wang et al 1976
HR_CO2 = -393.51;  % kJ/mol - Pro/II
HR_H2O = -241.82;  % kJ/mol - Pro/II
HR_Proton = 0;     % kJ/mol

MM_Glu = 0.180;    % kg/mol
MM_Xyl = 0.150;    % kg/mol
MM_Xyo = 0.152;    % kg/mol
MM_NH4 = 0.018;    % kg/mol
MM_O2 = 0.032;     % kg/mol
MM_X = 0.0246;     % kg/mol
MM_CO2 = 0.044;    % kg/mol
MM_H2O = 0.018;    % kg/mol
MM_Proton = 0.001; % kg/mol

%% BBM Rates & Herbert-Pirt relation parameters

a_Glu = par(9);
ms_Glu = par(10);
a_Xyl = par(11);
b_Xyl = par(12);
ms_Xyl = par(13);
a_Xyo = par(14);
ms_Xyo = par(15);

[q_Glu, q_Xyl, mu, q_Xyo] = rates(y,par);

%%%
q_Glu = q_Glu .* MM_X ./ MM_Glu;
q_Xyl = q_Xyl .* MM_X ./ MM_Xyl;
mu = mu;
q_Xyo = q_Xyo .* MM_X ./ MM_Xyo;

a_Glu = a_Glu * MM_X / MM_Glu;
ms_Glu = ms_Glu;
a_Xyl = a_Xyl * MM_X / MM_Xyl;
b_Xyl = b_Xyl * MM_Xyo / MM_Xyl;
ms_Xyl = ms_Xyl;
a_Xyo = a_Xyo * MM_X / MM_Xyo;
ms_Xyo = ms_Xyo;
%%%

q_Xyo_save = q_Xyo;
q_Xyo = abs(q_Xyo);

%% Process reactions
% Process Reaction - Glucose, growth
A1 = [[0 0 1 0 0];...
      [0 0 0 2 0];...
      [2 0 2 1 0];...
      [0 1 0 0 0];...
      [0 4 0 0 1]];
  
b1 = [[6*a_Glu - 1];...
      [12*a_Glu - 1.8];...
      [6*a_Glu - 0.5];...
      [-0.2];...
      [0]];
  
vec1 = A1\b1;


% Process Reaction - Glucose, maintenance
A2 = [[0 1 0];...
      [0 0 2];...
      [2 2 1]];

  
b2 = [[6];...
      [12];...
      [6]];

  
vec2 = A2\b2;


% Process Reaction - Xylose, growth
A3 = [[0 0 1 0 0];...
      [0 0 0 2 0];...
      [2 0 2 1 0];...
      [0 1 0 0 0];...
      [0 4 0 0 1]];
  
b3 = [[5*a_Xyl - 1];...
      [10*a_Xyl - 1.8];...
      [5*a_Xyl - 0.5];...
      [-0.2];...
      [0]];
  
vec3 = A3\b3;


% Process Reaction - Xylose, production
A4 = [[0 0 1 0 0];...
      [0 0 0 2 0];...
      [2 0 2 1 0];...
      [0 1 0 0 0];...
      [0 4 0 0 1]];
  
b4 = [[5*b_Xyl - 5];...
      [10*b_Xyl - 12];...
      [5*b_Xyl - 5];...
      [0];...
      [0]];
  
vec4 = A4\b4;

% Procses Reaction - Xylose, maintenance
A5 = [[0 1 0];...
      [0 0 2];...
      [2 2 1]];

  
b5 = [[5];...
      [10];...
      [5]];

  
vec5 = A5\b5;

% Process Reaction - Xylitol, growth
A6 = [[0 0 1 0 0];...
      [0 0 0 2 0];...
      [2 0 2 1 0];...
      [0 1 0 0 0];...
      [0 4 0 0 1]];
  
b6 = [[5*a_Xyo - 1];...
      [12*a_Xyo - 1.8];...
      [5*a_Xyo - 0.5];...
      [-0.2];...
      [0]];
  
vec6 = A6\b6;


% Process Reaction - Xylitol, maintenance
A7 = [[0 1 0];...
      [0 0 2];...
      [2 2 1]];

  
b7 = [[5];...
      [12];...
      [5]];

  
vec7 = A7\b7;


%% Rate parameters
% Oxygen
q_O2_Glu = [vec1(1), vec2(1)];
q_O2_Xyl = [vec3(1), vec4(1), vec5(1)];
q_O2_Xyo = [vec6(1), vec7(1)];

% Ammonium
q_NH4_Glu = [vec1(2)];
q_NH4_Xyl = [vec3(2), vec4(2)];
q_NH4_Xyo = [vec6(2)];

% Carbon dioxide
q_CO2_Glu = [vec1(3), vec2(2)];
q_CO2_Xyl = [vec3(3), vec4(3), vec5(2)];
q_CO2_Xyo = [vec6(3), vec7(2)];

% Water
q_H2O_Glu = [vec1(4), vec2(3)];
q_H2O_Xyl = [vec3(4), vec4(4), vec5(3)];
q_H2O_Xyo = [vec6(4), vec7(3)];

% Protons
q_Proton_Glu = [vec1(5)];
q_Proton_Xyl = [vec3(5), vec4(5)];
q_Proton_Xyo = [vec6(5)];

%% Rates
Glucose = y(:,1);
regime1 = length(Glucose(Glucose > 1));

Xylose = y(:,2);
regime2 = length(Xylose(Xylose > 1));
if regime2 < regime1
    regime2 = regime1;
end

total = length(Glucose);
reg = [regime1,regime2,total];

q_Glu = -1 .* q_Glu;
q_Xyl = -1 .* q_Xyl;
mu = mu;
q_Xyo = q_Xyo_save;

q_O2a = q_O2_Glu(1) .* mu(1:regime1) + q_O2_Glu(2) * ms_Glu;
q_O2b = q_O2_Xyl(1) .* mu(regime1+1:regime2) + q_O2_Xyl(2) .* q_Xyo(regime1+1:regime2) + q_O2_Xyl(3) * ms_Xyl;
q_O2c = q_O2_Xyo(1) .* mu(regime2+1:total) + q_O2_Xyo(2) * ms_Glu;
q_O2 = horzcat(q_O2a, q_O2b, q_O2c);

q_NH4a = q_NH4_Glu(1) .* mu(1:regime1);
q_NH4b = q_NH4_Xyl(1) .* mu(regime1+1:regime2) + q_NH4_Xyl(2) .* q_Xyo(regime1+1:regime2);
q_NH4c = q_NH4_Xyo(1) .* mu(regime2+1:total);
q_NH4 = horzcat(q_NH4a, q_NH4b, q_NH4c);

q_CO2a = q_CO2_Glu(1) .* mu(1:regime1) + q_CO2_Glu(2) * ms_Glu;
q_CO2b = q_CO2_Xyl(1) .* mu(regime1+1:regime2) + q_CO2_Xyl(2) .* q_Xyo(regime1+1:regime2) + q_CO2_Xyl(3) * ms_Xyl;
q_CO2c = q_CO2_Xyo(1) .* mu(regime2+1:total) + q_CO2_Xyo(2) * ms_Glu;
q_CO2 = horzcat(q_CO2a, q_CO2b, q_CO2c);

q_H2Oa = q_H2O_Glu(1) .* mu(1:regime1) + q_H2O_Glu(2) * ms_Glu;
q_H2Ob = q_H2O_Xyl(1) .* mu(regime1+1:regime2) + q_H2O_Xyl(2) .* q_Xyo(regime1+1:regime2) + q_H2O_Xyl(3) * ms_Xyl;
q_H2Oc = q_H2O_Xyo(1) .* mu(regime2+1:total) + q_H2O_Xyo(2) * ms_Glu;
q_H2O = horzcat(q_H2Oa, q_H2Ob, q_H2Oc);

q_Protona = q_Proton_Glu(1) .* mu(1:regime1);
q_Protonb = q_Proton_Xyl(1) .* mu(regime1+1:regime2) + q_Proton_Xyl(2) .* q_Xyo(regime1+1:regime2);
q_Protonc = q_Proton_Xyo(1) .* mu(regime2+1:total);
q_Proton = horzcat(q_Protona, q_Protonb, q_Protonc);

%%%
q_O2 = q_O2 * MM_O2;
q_NH4 = q_NH4 * MM_NH4;
q_CO2 = q_CO2 * MM_CO2;
q_H2O = q_H2O * MM_H2O;
q_Proton = q_Proton * MM_Proton;

q_Glu = q_Glu .* MM_Glu ./ MM_X;
q_Xyl = q_Xyl .* MM_Xyl ./ MM_X;
mu = mu;
q_Xyo = q_Xyo .* MM_Xyo ./ MM_X;
%%%


% Heat production rate
q_Heat = zeros(1,total);
q_Heat(:) = q_Glu(:).*HR_Glu/MM_Glu + q_Xyl(:).*HR_Xyl/MM_Xyl + q_Xyo(:).*HR_Xyo/MM_Xyl + q_CO2(:).*HR_CO2/MM_CO2 + q_NH4(:).*HR_NH4/MM_NH4 + mu(:).*HR_X/MM_X + q_H2O(:).*HR_H2O/MM_H2O;
  
end

%% Herbert-Pirt
function [a_Glu, ms_Glu, a_Xyl, b_Xyl, ms_Xyl] = Herbert_Pirt(rate_vector,y)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%% Check substrate regimes
reg1_Glu = y(1,:,1);
reg2_Glu = y(2,:,1);
reg3_Glu = y(3,:,1);

reg1_Glu = length(reg1_Glu(reg1_Glu > 0.1));
reg2_Glu = length(reg2_Glu(reg2_Glu > 0.1));
reg3_Glu = length(reg3_Glu(reg3_Glu > 0.1));

reg_Glu = [reg1_Glu, reg2_Glu, reg3_Glu];
clear reg1_Glu reg2_Glu reg3_Glu

reg1_Xyl = y(1,:,2);
reg2_Xyl= y(2,:,2);
reg3_Xyl = y(3,:,2);

reg1_Xyl = length(reg1_Xyl(reg1_Xyl > 0.1));
reg2_Xyl = length(reg2_Xyl(reg2_Xyl > 0.1));
reg3_Xyl = length(reg3_Xyl(reg3_Xyl > 0.1));

reg_Xyl= [reg1_Xyl, reg2_Xyl, reg3_Xyl];
clear reg1_Xyl reg2_Xyl reg3_Xyl

%% Split rate vectors
q_Glu_rates = squeeze(rate_vector(1,:,:));
q_Xyl_rates = squeeze(rate_vector(2,:,:));
mu_rates = squeeze(rate_vector(3,:,:));
q_Xyo_rates = squeeze(rate_vector(4,:,:));

clear rate_vector

q_Glu1 = q_Glu_rates(1,1:reg_Glu(1));
q_Glu2 = q_Glu_rates(2,1:reg_Glu(2));
q_Glu3 = q_Glu_rates(3,1:reg_Glu(3));

mu_Glu1 = mu_rates(1,1:reg_Glu(1));
mu_Glu2 = mu_rates(2,1:reg_Glu(2));
mu_Glu3 = mu_rates(3,1:reg_Glu(3));

q_Xyl1 = q_Xyl_rates(1,reg_Glu(1)+1:reg_Xyl(1));
q_Xyl2 = q_Xyl_rates(2,reg_Glu(2)+1:reg_Xyl(2));
q_Xyl3 = q_Xyl_rates(3,reg_Glu(3)+1:reg_Xyl(3));

mu_Xyl1 = mu_rates(1,reg_Glu(1)+1:reg_Xyl(1));
mu_Xyl2 = mu_rates(2,reg_Glu(2)+1:reg_Xyl(2));
mu_Xyl3 = mu_rates(3,reg_Glu(3)+1:reg_Xyl(3));

q_Xyo1 = q_Xyo_rates(1,reg_Glu(1)+1:reg_Xyl(1));
q_Xyo2 = q_Xyo_rates(2,reg_Glu(2)+1:reg_Xyl(2));
q_Xyo3 = q_Xyo_rates(3,reg_Glu(3)+1:reg_Xyl(3));

%% rates

q_Glu1 = mean(q_Glu1);
q_Glu2 = mean(q_Glu2);
q_Glu3 = mean(q_Glu3);

mu_Glu1 = mean(mu_Glu1);
mu_Glu2 = mean(mu_Glu2);
mu_Glu3 = mean(mu_Glu3);

q_Xyl1 = mean(q_Xyl1);
q_Xyl2 = mean(q_Xyl2);
q_Xyl3 = mean(q_Xyl3);

mu_Xyl1 = mean(mu_Xyl1);
mu_Xyl2 = mean(mu_Xyl2);
mu_Xyl3 = mean(mu_Xyl3);

q_Xyo1 = mean(q_Xyo1);
q_Xyo2 = mean(q_Xyo2);
q_Xyo3 = mean(q_Xyo3);

%% factors a,b for Glucose

% a_Glu = (q_Glu2 - q_Glu3) / (mu_Glu2 - mu_Glu3);
% ms_Glu = q_Glu2 - a_Glu * mu_Glu2;
A = [[mu_Glu2 1];[mu_Glu3 1]];
b = [[q_Glu2];[q_Glu3]];
vec = A\b;
a_Glu = vec(1);
ms_Glu = vec(2);


%% factors a,b for Xylose

A = [[mu_Xyl1 q_Xyo1 1];[mu_Xyl2 q_Xyo2 1];[mu_Xyl3 q_Xyo3 1]];
b = [[q_Xyl1];[q_Xyl2];[q_Xyl3]];
vec = A\b;
a_Xyl = vec(1);
b_Xyl = vec(2);
ms_Xyl = vec(3);
    

rates = [a_Glu, ms_Glu, a_Xyl, b_Xyl, ms_Xyl];

end

%% Rates
function [q_Glu, q_Xyl, mu, q_Xyo] = rates(y,par)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Concentrations
C_Glu = y(:,1);
C_Xyl = y(:,2);
C_X = y(:,3);
C_Xyo = y(:,4);

n = length(C_Glu);

%% Parameters
q_s_max_Glu = par(1);
q_s_max_Xyl = par(2);
q_s_max_Xyo = par(3);

K_Glu = par(4);
K_Xyl = par(5);
K_Xyo = par(6);

K_I_Glu = par(7);
K_I_Xyl = par(8);

a_Glu = par(9);
ms_Glu = par(10);

a_Xyl = par(11);
b_Xyl = par(12);
ms_Xyl = par(13);

a_Xyo = par(14);
ms_Xyo = par(15);

alpha = par(16);
beta = par(17);

%% Rates
% substrate uptake rate
% Calculation q_Glu - substrate uptake rate glucose
for i = 1:n
    q_Glu(i) = q_s_max_Glu * (C_Glu(i)/(K_Glu + C_Glu(i)));
end

% Calculation q_Xyl - substrate uptake rate xylose
for i = 1:n
    q_Xyl(i) = q_s_max_Xyl * (C_Xyl(i)/(K_Xyl + C_Xyl(i))) * (1/(1 + C_Glu(i)/K_I_Glu));
end

% Calculation q_Xyo - production rate xylitol
for i = 1:n
    q_Xyo(i) = (alpha * q_Xyl(i) + beta) * (1/(1 + K_I_Xyl/C_Xyl(i))) - q_s_max_Xyo * (C_Xyo(i)/(K_Xyo + C_Xyo(i))) * (1/(1 + C_Xyl(i)/K_I_Xyl));
end

% Calculation mu - Monod kinetic growth rate
for i = 1:n
    mu(i) = (q_Glu(i)/a_Glu - ms_Glu/a_Glu) + ((q_Xyl(i) - beta*b_Xyl - ms_Xyl) / (a_Xyl + alpha * b_Xyl)) + (q_Xyo(i)/a_Xyo - ms_Xyo/a_Xyo);
end

% Calculation mu - Monod kinetic growth rate
% for i = 1:n
%     mu(i) = mu_max_Glu * (C_Glu(i)/(K_Glu + C_Glu(i))) + mu_max_Xyl * (C_Xyl(i)/(K_Xyl + C_Xyl(i) + C_Glu(i)^2/K_I_Glu)) + mu_max_Xyo * (C_Xyo(i)/(K_Xyo + C_Xyo(i) + C_Xyl(i)^2/K_I_Xyl));
% end
% 
% % Calculation q_Glu - substrate uptake rate glucose
% for i = 1:n
%     q_Glu(i) = q_s_max_Glu * (C_Glu(i)/(K_Glu + C_Glu(i)));
% end
% 
% % Calculation q_Xyl - substrate uptake rate xylose
% for i = 1:n
%     q_Xyl(i) = q_s_max_Xyl * (C_Xyl(i)/(K_Xyl + C_Xyl(i) + C_Glu(i)^2/K_I_Glu));
% end
% 
% % Calculation q_Xyo - production rate xylitol
% for i = 1:n
%     q_Xyo(i) = alpha * q_Xyl(i) + beta - q_s_max_Xyo * (C_Xyo(i)/(K_Xyo + C_Xyo(i) + C_Xyl(i)^2/K_I_Xyl));
% end

end

%% Outflows
function [m_broth, c_out, M_air_in, M_air_out, M_nitro, M_titr, M_evap, M_biomass, H_ext] = Outflows(m_in, c_in, y, time, tlength, q_Glu, q_Xyl, mu, q_Xyo, q_O2, q_NH4, q_CO2, q_H2O, q_Proton, q_Heat, reg, rho_broth)

T_ferm = 273.15 + 30;  % K
T_ext = 273.15 + 20;   % K

Cp_air = 1;            % kJ/kg/K
Cp_H2O = 4.19;         % kJ/kg/K

% Flows/Masses for gas phase, nitrogen source and titrant
% Flow of air out
F_air_out = abs(q_CO2)'.* y(:,3) .* y(:,5) / 0.05; % y_CO2_out = 0.05 due to CO2 inhibiton
M_air_out = FluxToMass(F_air_out,reg,tlength,time) * 1e-3; % [kg]
M_CO2_out = M_air_out * 0.05;


% Flow of evaporated water
F_evap = F_air_out .* 0.0584; % y_H20_out = 0.0584 due to saturation pressure at 30degC, phi = 0.2, assuming that air is 10% saturated when exiting the fermentor
M_evap = FluxToMass(F_evap,reg,tlength,time) * 1e-3; % [kg]

% Flow of air in
F_air_in = F_air_out + abs(q_O2)'.* y(:,3) .* y(:,5) - abs(q_CO2)'.*y(:,3) .* y(:,5);
M_air_in = FluxToMass(F_air_in,reg,tlength,time) * 1e-3; % [kg]

% Fraction of oxygen in flow air out
y_O2_out = (F_air_in .* 0.21 - abs(q_O2)'.* y(:,3) .* y(:,5)) ./ F_air_out;
y_O2_out = y_O2_out(1,1);

% Mass of transfered oxygen
M_O2_in = M_air_in * 0.21 - M_air_out * y_O2_out;

% Flow of pure nitrogen source
F_nitro = abs(q_NH4)' .* y(:,3) .* y(:,5);
M_nitro = FluxToMass(F_nitro,reg,tlength,time) * 1e-3; % [kg]

% Flow of pure titrant
F_titr = abs(q_Proton)' .* y(:,3) .* y(:,5);
M_titr = FluxToMass(F_titr,reg,tlength,time) * 1e-3; % [kg]

% Flow of water out of liquid phase
F_H2O = abs(q_H2O)' .* y(:,3) .* y(:,5);
M_H2O = FluxToMass(F_H2O,reg,tlength,time) * 1e-3; % [kg]

% Total mass balance
m_broth = m_in + M_nitro + M_titr + M_air_in - M_air_out - M_evap;
delta = (m_broth - m_in)/m_in * 100;

% Output masses
mm_broth = y(end,[1,2,4]) * y(end,5) * 1e-3; % [kg]
M_biomass = y(end,3) * y(end,5) * 1e-3; % [kg]

mm_out = c_in /100 * m_in; % kg

mm_out(4) = mm_broth(1); % kg
mm_out(2) = mm_broth(2); % kg
mm_out(18) = mm_broth(3); % kg

mm_out(17) = 0; % reset to zero
mm_out(17) = m_broth - sum(mm_out); % remaining mass is water

c_out = mm_out ./ m_broth .* 100;

% Heat balance
F_HR = abs(q_Heat)' .* y(:,3) .* y(:,5);
HR = FluxToMass(F_HR,reg,tlength,time) * 1e-3; % [kJ]

H_in = M_air_in * Cp_air * T_ext;
H_out = M_air_out * Cp_air * T_ferm + M_evap * Cp_H2O * T_ferm;

H_ext = H_out - H_in + HR;

end


%% FluxToMass
function m = FluxToMass(f,reg,tlength,time)
% Calculating absolute masses from fluxes in different substrate regimes

f_Glu = f([1:reg(1)]);

if reg(1) < reg(2)
    f_Xyl = f([reg(1)+1:reg(2)]);
end

if reg(2) < reg(3)
    f_Xyo = f([reg(2)+1:reg(3)]);
end

m_Glu = mean(f_Glu) * reg(1)/tlength * time;

if reg(2) > reg(1)
    m_Xyl = mean(f_Xyl) * (reg(2) - reg(1))/tlength * time;
else
    m_Xyl = 0;
end

if reg(3) > reg(2)
    m_Xyo = mean(f_Xyo) * (reg(3) - reg(2))/tlength * time;
else
    m_Xyo = 0;
end

m = m_Glu + m_Xyl + m_Xyo;

end

%% Sizing
function V_reactor = Sizing(m_broth, rho_broth, time)

m_broth = m_broth / 1000; % Broth mass  [t]

% Volumetric capacity per hour
m_daily = m_broth / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly = m_hourly / rho_broth; % broth density [t/m3]

V_reactor = V_total_hourly * time;

end

%% Costing
function FCI = costing_fermentation_xylitol(m_broth)

m_daily = m_broth/300; % assuming the plant operates 300 d/y [kg/d]
m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 425878; % kg/h

% Fixed capital investment for unit
FCI00 = 3362334; % $(2010)
n = 10; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;


end
