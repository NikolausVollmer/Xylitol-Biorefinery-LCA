function [m_hydrolyzate,c_out_hydrolyzate,m_lignin,c_out_lignin, mf, hf, design] = hydrolysis_model(m_residue,c_in,stats)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

% Parameters
par = hydrolysis_parameters();

% Stats
t = stats(1);   % h
T = stats(2);   % degC
pH = stats(3);  % -
T0 = stats(4);  % degC

stats = [T pH];

% Input masses
m_in = c_in * m_residue / 100; % [kg]
m_biomass = sum(c_in(1:13) * m_residue / 100); % [kg]

x0(1) = m_in(1) * 1000 / m_biomass;  % Xylan (Xyn) in g / kg biomass
x0(2) = m_in(2) * 1000 / m_biomass;  % Xylose (Xyl) in g / kg biomass
x0(3) = m_in(3) * 1000 / m_biomass;  % Cellulose (Cel) in g / kg biomass
x0(4) = 0;                                       % Cellobiose (Clb) in g / kg biomass
x0(5) = m_in(4) * 1000 / m_biomass;  % Glucose (Glu) in g / kg biomass
x0(6) = m_in(11) * 1000 / m_biomass; % Furfural (Fur) in g / kg biomass

x0(7) = 0.01 * x0(3);                             % Enzymes for r1 - free in g / kg biomass
x0(8) = 0;                                       % Enzymes for r1 - bound in g / kg biomass
x0(9) = 0.02 * x0(3);                            % Enzymes for r2,3 - free in g / kg biomass
x0(10) = 0;                                      % Enzymes for r2,3 - bound in g / kg biomass
x0(11) = 0.02 * x0(3);                            % Enzymes for r3,4 - free in g / kg biomass
x0(12) = 0;                                      % Enzymes for r3,4 - bound in g / kg biomass

m_water_res = m_in(17); % [kg]
m_acid_res = m_in(14); % [kg]

[m_base_pure, m_base_water] = mass_base(m_water_res, m_acid_res, pH);
m_water = m_water_res + m_base_water; % [kg]
m_water_extra = 9*m_water;
m_water = m_water + m_water_extra; % [kg] - dilution for fermentation

m_base = m_base_pure; % [kg]

m_enzymes = (x0(7) + x0(9) + x0(11)) * m_biomass * 1e-3; % [kg]

% Time span
tspan = linspace(0,t,t+1);

%% Reaction
options = odeset('RelTol',1e-7,'AbsTol',1e-8);
[~,y] = ode45(@hydrolysis_kinetics,tspan,x0,options,par,stats);

% figure
% hold on
% plot(tspan,y(:,3));
% plot(tspan,y(:,4));
% plot(tspan,y(:,5));
% plot(tspan,y(:,7));
% plot(tspan,y(:,8));
% title("Concentrations")
% xlabel("time [h]")
% ylabel("Concentration [g/kg biomass]")

%% Output
% absolute mass of components
yend = y(end,:); % [g/kg biomass]
m_res = yend * m_biomass / 1000; % [kg]

[m_hydrolyzate,c_out_hydrolyzate,m_lignin,c_out_lignin] = output_mass_hydrolysis(m_res, m_in, m_water, m_acid_res, m_base);

% Heat
[H_heat, H_cool] = hydrolysis_energy_balance(m_residue, m_water, m_base, T, T0);

% Sizing
V_Reactor = sizing_hydrolysis(m_biomass, m_water, m_base, t);

% Costing
FCI = costing_hydrolysis(m_biomass, m_water, m_base);

% Function output
mf(1) = m_base_water;
mf(2) = m_base;
mf(3) = m_enzymes;
mf(4) = m_water_extra;

hf = [H_heat, H_cool];

design = [V_Reactor, FCI];

end

%% Calculation of base amount
function [m_base_pure, m_base_water] = mass_base(m_water, m_acid, pH)
Mw_H2SO4 = 0.09808; % kg/mol
n_acid0 = m_acid/Mw_H2SO4; % assuming that one proton goes into solution and forms hydroxyonium ions

rho_water = 1; % kg/L
V_water = m_water / rho_water; % assuming density of the liquid phase in the hydrolyzate is equal to water

pH0 = -log10(n_acid0/V_water); % pH of residue before base is added

n_acid = V_water * 10^-pH; % amount of acid that should be present for optimal pH

n_base = n_acid0 - n_acid; % amount of base that needs to be added for increasing the pH, assuming that one hydroxy ion pairs with one hydroxonium ion

Mw_NaOH = 0.039997; % kg/mol assuming pure sodium hydroxide is used
m_base_pure = n_base * Mw_NaOH; % kg

m_base_water = 1/1 * 1000/39.997 * m_base_pure; % assuming a 1M base solution

end

%% Calculation of output mass
function [m_hydrolyzate,c_out_hydrolyzate,m_residual,c_out_residual] = output_mass_hydrolysis(m_res, m_in, m_water, m_acid, m_base)

% mass of solid residues of the biomass
% assuming a residual humidity after phase separation
% assuming an ideally mixed hydrolyzate exists
m_solid_dry = m_res(1) + m_res(3) + m_in(5) + m_in(7) + m_in(13);

phi = 0.25; % humidity of residual

m_residual_water = m_solid_dry * phi; % water in residual
wfrac = m_residual_water / m_water; % fraction of water in residual
m_residual_acid = wfrac * m_acid; % acid in residual
m_residual_base = wfrac * m_base; % base in residual
m_residual_enzymes = wfrac * sum(m_res([7,9,11])) + sum(m_res([8,10,12])); % enzymes in residual

m_res_residual = zeros(1,21);
m_res_residual([1,3]) = m_res([1,3]); % all solids in residual
m_res_residual([2,4]) = m_res([2,5]) .* wfrac; % liquid fraction in residual
m_res_residual(5) = m_in(5); % arabinan fraction in residual
m_res_residual([6,8,9,10,11,12]) = m_in([6,8,9,10,11,12]) .* wfrac; % monomers from pretreatment in residual
m_res_residual(13) = m_in(13); % lignin in residual
m_res_residual(17) = m_residual_water; % fraction of water in residual
m_res_residual(14) = m_residual_acid; % fraction of acid in residual
m_res_residual(15) = m_residual_base; % fraction of base in residual
m_res_residual(21) = m_residual_enzymes; % fraction of enzymes in residual
% 16, 18, 19 and 20 are =0 in solid phase

m_residual = sum(m_res_residual);

% mass of hydrolyzate
m_hydrolyzate_water = m_water - m_residual_water;
m_hydrolyzate_acid = m_acid - m_residual_acid;
m_hydrolyzate_base = m_base - m_residual_base;
m_hydrolyzate_enzymes = (1-wfrac) * sum(m_res([7,9,11]));

m_res_hydrolyzate = zeros(1,21); % no solids in hydrolyzate
m_res_hydrolyzate([2,4])  = m_res([2,5]) .* (1 - wfrac); % remaining fraction in hydrolyzate
m_res_hydrolyzate([6,8,9,10,11,12]) = m_in([6,8,9,10,11,12]) .* (1 - wfrac); % monomers from pretreatment in hydrolyzate
m_res_hydrolyzate(17) = m_hydrolyzate_water; % remanining fraction of water in hydrolyzate
m_res_hydrolyzate(14) = m_hydrolyzate_acid; % remaining fraction of acid in hydrolyzate
m_res_hydrolyzate(15) = m_hydrolyzate_base; % remaining fraction of base in hydrolyzate
m_res_hydrolyzate(21) = m_hydrolyzate_enzymes; % remaining fraction of enzymes in hydrolyzate
m_hydrolyzate = sum(m_res_hydrolyzate);
% 13, 16, 18, 19 and 20 are =0 in liquid phase

% outlet concentrations
c_out_residual = m_res_residual ./ m_residual .* 100;
c_out_hydrolyzate = m_res_hydrolyzate ./ m_hydrolyzate .* 100;

end

%% ENERGY Balance
function [H_heat, H_cool] = hydrolysis_energy_balance(m_residue, m_water, m_base, T, T0)
Cp_H2O = 4.19;   % heat capacity of water in kJ/kg/K
Cp_WS = 1.61;    % heat capacity of wheat straw in kJ/kg/K
Cp_base = 0.05952;  % heat capacity of sodium hydroxide in kJ/kg/K (from NIST)

H_heat = (m_residue * Cp_WS + m_water * Cp_H2O + m_base * Cp_base) * (T + 273.15 - T0 + 273.15); % Heating enthalpy in kJ
H_cool = (m_residue * Cp_WS + m_water * Cp_H2O + m_base * Cp_base) * (T + 273.15 - T0 + 273.15 + 10); % Cooling enthalpy in kJ

end

%% Sizing
function V_Reactor = sizing_hydrolysis(m_biomass, m_water, m_base, time)

m_total = (m_biomass + m_water + m_base) / 1000;

% Densities
rho_water = 1;   % t/m3

% Volumetric capacity per hour
m_daily = m_total / 300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily / 24;       % assuming the plant opperates 24 h/d [t/h]

V_total_hourly =  m_hourly / rho_water;

% Number and volume of reactors to satisfy capacity
V_Reactor = V_total_hourly * time; % assuming a reactor with constant throughput (extruder-like, Prunescu et al. (2014)), with given residence time

end

%% Costing
function FCI = costing_hydrolysis(m_biomass, m_water, m_base)

m_total = m_biomass + m_water + m_base;

m_daily = m_total/300; % assuming the plant operates 300 d/y [t/d]
m_hourly = m_daily/24;

% Capacity own plant
CP = m_hourly; % kg/h

% Capacity NREL Plant
CP0 = 379938; % kg/h

% Fixed capital investment for unit
FCI00 = 4245565; % $(2010)
n = 10; % ten years difference 2020 - 2010
FCI0 = FCI00 * (1+0.01)^n;

% Plant Capacity ration
x = 0.7; % extrapolation factor, based on the report

FCI = FCI0 * (CP/CP0)^x;


end