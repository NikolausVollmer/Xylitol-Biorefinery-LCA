function dydx = hydrotreatment_kinetics(t,y,stats)
%HYDROTREATMENT KINETICS OF PYROLYSIS OIL FROM LIGNOCELLULOSIC BIOMASS
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 08.04.2021

R = 8.314e-3;            % J/mol/K - universal gas constant
rho_cat = 1e3;              % kg catalyst/m3 - catalytic bed density (according to Purdue/Dow webpage)

T = 273.15 + stats(1);
v = stats(2);            % m/h - constant gas flow velocity
rho_gas = stats(3);     % g/m3 - mass density of biooil (gas)

[A,E] = hydrotreatment_parameters();

% Catalyst degradation parameters
a1 = 0.98;
a2 = 3.3316 - 0.0042 * T; % only valid between T = [698,748] K

%% Reaction equations
% 1 - Oxygenates to hydrocarbons
% 2 - Oxygenates to alkylphenolics
% 3 - Oxygenates to alkylaromatics
% 4 - Alkylphenolics to alkylaromatics
% 5 - Hydrocarbons to alkylaromatics
% 6 - Oxygenates to gaseous products
% 7 - Alkylphenolics to gaseous producs

r = zeros(7,1);


r(1) = A(1) * exp(-E(1)/(R*T)) * y(1) * a1;
r(2) = A(2) * exp(-E(2)/(R*T)) * y(1) * a1;
r(3) = A(3) * exp(-E(3)/(R*T)) * y(1) * a1;
r(4) = A(4) * exp(-E(4)/(R*T)) * y(4) * a1;
r(5) = A(5) * exp(-E(5)/(R*T)) * y(3) * a1;
r(6) = A(6) * exp(-E(6)/(R*T)) * y(1) * a2;
r(7) = A(7) * exp(-E(7)/(R*T)) * y(4) * a2;

%% Stoichiometric matrix & component balances
% 1 - Oxygenates
% 2 - Gaseous products
% 3 - Hydrocarbons
% 4 - Alkylphenolics
% 5 - Alkylaromatics


S = zeros(7,5);

S(1,1) = -2; S(1,3) = 1;
S(2,1) = -3; S(2,4) = 1;
S(3,1) = -3; S(3,5) = 1;
S(4,4) = -1; S(4,5) = 1;
S(5,3) = -3; S(5,5) = 2;
S(6,1) = -1; S(6,2) = 3;
S(7,4) = -1; S(7,2) = 9;

% S(1,1) = -1; S(1,3) = 1;
% S(2,1) = -1; S(2,4) = 1;
% S(3,1) = -1; S(3,5) = 1;
% S(4,4) = -1; S(4,5) = 1;
% S(5,3) = -1; S(5,5) = 1;
% S(6,1) = -1; S(6,2) = 1;
% S(7,4) = -1; S(7,2) = 1;

dydx = (rho_cat/(rho_gas * v)) .* (S'*r);


