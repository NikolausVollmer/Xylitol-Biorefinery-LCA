function MW = hydrotreatment_mw()
%PARAMETERS FOR THE PYROLYSIS MODEL FOR LIGNOCELLULOSIC BIOMASS PYROLYSIS 
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 04.03.2021


% 1 - Oxygenates
% 2 - Gaseous products
% 3 - Hydrocarbons
% 4 - Alkylphenolics
% 5 - Alkylaromatics
% 6 - Thermal lignin
% 7 - Char/Coke
% 8 - Hydrogen
% 9 - Water

MW(1) = 90.078;
MW(2) = 30.025;
MW(3) = 84.162;
MW(4) = 152.193;
MW(5) = 118.179;
MW(6) = 292.290;
MW(7) = 230.310;
MW(8) = 2.016;
MW(9) = 18.015;


% % 1 - Cellulose - glucan / C6H10O5 monomer
% % 2 - Cellulose-A
% 
% % 3 - Softwood hemicellulose (GMSW) - glucomannan / C5H8O4 monomer
% % 4 - Hardwood hemicellulose (XYHW) - xylan / C5H8O4 monomer
% % 5 - Grass hemicellulose (XYGR) - xylan / C5H8O4 monomer
% % 6 - Hemicellulose-1
% % 7 - Hemicellulose-2
% 
% % 8 - LigC - p-coumaryl alcohol unit / C15H14O4 monomer
% % 9 - LigO - sinapyl alcohol unit / C20H22O10 dimer
% % 10 - LigH - sinapyl alcohol unit / C22H28O9 dimer
% % 11 - LigCC
% % 12 - LigOH
% % 13 - Lig
% 
% % 14 - 3-Hydroxypropanal
% % 15 - Proprionaldehyd
% % 16 - Propanedial
% % 17 - Hydroxyacetaldehyde
% % 18 - Glyoxal
% % 19 - Acetaldehyde
% % 20 - Acetic acid
% % 21 - Ethanol
% % 22 - Formaldehyde
% % 23 - Formic acid
% % 24 - Methanol
% 
% % 25 - Xylosan
% % 26 - Levoglucosan
% % 27 - Furfural
% % 28 - 5-HMF
% 
% % 29 - Anisol
% % 30 - Cresol
% % 31 - Phenol
% % 32 - Vanillin
% % 33 - Macromolecular Lignin (HMWL)
% 
% % 34 - C2H6
% % 35 - C2H4
% % 36 - CH4
% % 37 - Carbon monooxide
% % 38 - Carbon dioxide
% % 39 - Hydrogen
% % 40 - Water
% 
% % 41 - GH2
% % 42 - GCO
% % 43 - GCO2
% % 44 - GCOH2-loose
% % 45 - GCOH2-stiff
% % 46 - GC2H6
% % 47 - GC2H4
% % 48 - GCH4
% % 49 - GCH3OH
% % 50 - GPhenol
% 
% % 51 - Char
% % 52 - Glucose
% % 53 - Xylose
% 
% MW(1) = 162.1413;
% MW(2) = 0;
% 
% MW(3) = 150.13;
% MW(4) = 150.13;
% MW(5) = 150.13;
% MW(6) = 0;
% MW(7) = 0;
% 
% MW(8) = 258.2663;
% MW(9) = 422.3765;
% MW(10) = 436.4459;
% MW(11) = 0;
% MW(12) = 0;
% MW(13) = 0;
% 
% MW(14) = 74.08;
% MW(15) = 58.08;
% MW(16) = 72.06266;
% MW(17) = 60.052;
% MW(18) = 58.04;
% MW(19) = 44.05;
% MW(20) = 60.052;
% MW(21) = 46.07;
% MW(22) = 30.031;
% MW(23) = 46.03;
% MW(24) = 32.04;
% 
% MW(25) = 132.115;
% MW(26) = 162.141;
% MW(27) = 96.0846;
% MW(28) = 126.11;
% 
% MW(29) = 108.14;
% MW(30) = 108.14;
% MW(31) = 94.113;
% MW(32) = 152.149;
% MW(33) = 380.4723;
% 
% MW(34) = 30.07;
% MW(35) = 26.04;
% MW(36) = 16.04;
% MW(37) = 28.01;
% MW(38) = 44.01;
% MW(39) = 2.0157;
% MW(40) = 31.998;
% 
% MW(41) = 2.0157;
% MW(42) = 28.01;
% MW(43) = 44.01;
% MW(44) = 41.2; % approximately, assuming char = carbon
% MW(45) = 32.8; % approximately
% MW(46) = 30.07;
% MW(47) = 26.04;
% MW(48) = 16.04;
% MW(49) = 32.04;
% MW(50) = 94.113;
% 
% MW(51) = 12; % approximately, assuming char = carbon
% MW(52) = 180.156;
% MW(53) = 150.13;



end

