function [A,E] = hydrotreatment_parameters()
%PARAMETERS HYDROTREATMENT KINETICS OF PYROLYSIS OIL FROM LIGNOCELLULOSIC BIOMASS
% written by Nikolaus Vollmer, PROSYS, DTU, nikov@kt.dtu.dk, 08.04.2021

%% Frequency factors - molC/g/h/bar
A = zeros(7,1);

A(1) = 335.15;
A(2) = 108.08;
A(3) = 2487.9;
A(4) = 6250.4;
A(5) = 176.76;
A(6) = 3.7587;
A(7) = 3047.7;

%% Activation energies - kJ/mol
E = zeros(7,1);

E(1) = 27.181;
E(2) = 29.464;
E(3) = 32.162;
E(4) = 86.648;
E(5) = 29.053;
E(6) = 141.57;
E(7) = 29.945;

end

