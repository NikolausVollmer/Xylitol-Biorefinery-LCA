function par = fermentation_succ_parameters()
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

q_Glu_max = 0.6531;
K_Glu = 0.2677;
K_I_Glu = 1.9381e3;
K_I_Ac = 43.3683*1.2;

a_Glu = 0.0951;
b1_Glu_Sac = 0.7673;
b1_Glu_Fac = 0.782;
b1_Glu_Aac = 0.7825;
ms_Glu = 0.005;

beta_Sac = 0.2259;
beta_Fac = 0.2059;
beta_Aac = 0.2276;

b2_Glu_Sac = 0.575*1.2;
b2_Glu_Fac = 0.0985;
b2_Glu_Aac = 0.1089;

C_I_Ac = 5.4684;

par = [q_Glu_max, K_Glu, K_I_Glu, K_I_Ac, ...
    a_Glu, b1_Glu_Sac, b1_Glu_Fac, b1_Glu_Aac, ...
    ms_Glu, beta_Sac, beta_Fac, beta_Aac, b2_Glu_Sac, b2_Glu_Fac, b2_Glu_Aac, C_I_Ac];

end

