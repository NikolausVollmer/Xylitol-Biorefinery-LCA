%Method of moment function defining the model
function dxdt = crystallization_xylitol_mom(t, x, par_solvent, par_Xyo, par_design, stats)

%% STATS
m_H2O = stats(1);      % Mass of H2O - [kg]
F_AS = stats(2);       % Flow rate of antisolvent - [kg/s]
V0 = stats(3);         % Initial Volume of system - [m3]
m0_Xyo = stats(4);

%% PARAMETERS
% Solvent
rho_L = par_solvent(1);     % density of water - [kg/m3]
rho_AS = par_solvent(2);    % density of the antisolvent - [kg/m3]
Mw_L = par_solvent(3);      % molar mass of the liquid - [kg/m3]
Mw_AS = par_solvent(4);     % molar mass of the antisolvent - [kg/m3]
Cp_L = par_solvent(5);      % heat capacity of water - [kg/m3]
Cp_AS = par_solvent(6);     % heat capacity of the antisolvent - [kg/m3]

% Xylitol
rho_Xyo = par_Xyo(1);
DH_fus_Xyo = par_Xyo(2);
ka = par_Xyo(3);
kv = par_Xyo(4);
Mw_Xyo = par_Xyo(5);
L0 = par_Xyo(6);

% Design
U = par_design(1);         % Heat transfer coefficient - [W/m2/degC]
T0_C = par_design(2);      % Initial coolant temperature - [degC]
A = par_design(3);         % Heat transfer area - [m2]
F_C = par_design(4);       % Coolant flowrate - [kg/s]
V_j = par_design(5);       % Cooling jacket volume - [m3]

%Defining change in solvent properties                   
w_AS = (x(8) - m_H2O) / x(8);                            % Weight fraction of antisolvent in solvent - [-]
rho_Sol = 1 / (w_AS/rho_AS + (1-w_AS)/rho_L);            % Density of solvent - [kg/m3]
X_AS = (x(8)/rho_Sol - m_H2O/rho_L) / (x(8,1)/rho_Sol);  % Volume fraction of antisolvent - [-]
Mw_Sol = Mw_L * (1-X_AS) + Mw_AS * X_AS;                 % Molecular weight of solvent - [g/mol]
Cp_Sol = 0;


%% Solubility
%The regression was done in matlab using polynomial regression to the 3
%degree Csat vs 1/T and w_a

%Regression parameters
% p00 = 1.635;
% p10 = -44.2;
% p20 = 257.4;
% p11 = -0.152;
% p01 = 8.032*10^(-4);
% p02 = -1.703*10^(-4);
p00 =       0.439; %  (-0.8005, 1.679)
p10 =     0.07287; %  (-0.005897, 0.1516)
p01 =      0.6919; %  (-14, 15.38)
p20 =   -0.002748; %  (-0.007239, 0.001743)
p11 =     -0.1995; %  (-0.5596, 0.1605)
p02 =      -9.889; %  (-73.44, 53.66)
p30 =    9.57e-05; %  (-1.73e-05, 0.0002087)
p21 =    0.005098; %  (-0.005521, 0.01572)
p12 =       0.352; %  (-0.4807, 1.185)
p03 =        27.9; %  (-99.3, 155.1)
p40 =  -8.875e-07; %  (-1.894e-06, 1.193e-07)
p31 =  -0.0001371; %  (-0.0003292, 5.491e-05)
p22 =  -0.0008635; %  (-0.012, 0.01027)
p13 =     -0.4968; %  (-1.427, 0.4337)
p04 =      -33.14; %  (-153.1, 86.84)
p41 =   1.604e-06; %  (6.819e-08, 3.14e-06)
p32 =   -3.64e-05; %  (-0.0001186, 4.583e-05)
p23 =   0.0009431; %  (-0.004549, 0.006435)
p14 =      0.2545; %  (-0.1538, 0.6629)
p05 =       14.26; %  (-28.97, 57.48)

%Solubility
T = x(6); % Temperature in crystallizer - [degC]
%Csat = exp(p00 + p10*(1/T) + p01*w_AS*100 + p20*(1/T)^2 + p11*(1/T)*w_AS*100 + p02*(w_AS*100)^2); %[kg Xyl/kg solvent]

Csat = p00 + p10*T + p01*w_AS + p20*(T^2) + p11*T*w_AS + p02*(w_AS^2) + p30*(T^3) + ...
    p21*(T^2)*w_AS + p12*T*(w_AS^2) + p03*(w_AS^3) + p40*(T^4) + p31*(T^3).*w_AS + ...
    p22*(T^2)*(w_AS^2) + p13*T*(w_AS^3) + p04*(w_AS^4) + p41*(T^4)*w_AS + p32*(T^3)*(w_AS^2) + ...
    p23*(T^2)*(w_AS^3) + p14*T*(w_AS^4) + p05*(w_AS^5);

%%Supersaturation
Creal = x(5) / x(8); % kg Xyl / kg solvent
% Creal = x(5) / m_H2O;

if Creal <= Csat
    Delta_C = 0;
else
    Delta_C = Creal - Csat;
end

%Kinetics
if Creal <= Csat
    G = 0;
    B = 0;
else 
    G = (5.105*10^(-9)*w_AS*100+3.892*10^(-8)) * Delta_C^(-2.217*10^(-2) * w_AS*100 + 2.892);   % [m/s]
    B = ((1.874*10^5*w_AS*100+9.263*10^6) * Delta_C^(-4.364*10^(-2) * w_AS*100 + 4.882));    % [#/m^3/s] - formula for primary nucleation 
    % B = (1.874*10^5*w_AS*100+9.263*10^6) * Delta_C^(-4.364*10^(-2) *
    % w_AS*100 + 4.882) * rho_Sol;    % [#/m^3/s] - formula for secondary
    % nucleation with rho_Sol = magma density?
end


%% Method of Moments
% according to work from Zoltan Nagy, 2008, ESCAPE18 Proceedings, "A
% population balance model approach for crystallization product engineering
% via distribution shaping control"

% x(1) - mu0(0)
% x(2) - mu1(0) 
% x(3) - mu2(0)
% x(4) - mu3(0) 
% x(5) - mass balance xylitol in liquid phase, m_Xyo - [kg] 
% x(6) - Temperature in liquid phase, T - [degC]
% x(7) - Temperature in cooling jacket, T - [degC]
% x(8) - mass balance solvent [kg]

dxdt(1,1) = B;                                       % [#/m^3/s]
dxdt(2,1) = G*x(1) + B * L0;                         % [m/m^3/s]
dxdt(3,1) = 2*G*x(2) + B * L0^2;                       % [m^2/m^3/s]
dxdt(4,1) = 3*G*x(3) + B * L0^3;                       % [m^3/m^3/s]

dxdt(5,1) = - rho_Xyo * kv * dxdt(4,1) / rho_Sol * x(8);       % [kg Xyo/s]

dxdt(6,1) = ((DH_fus_Xyo/Mw_Xyo) * rho_Xyo/rho_Sol * kv * (3*G*x(3) + B*L0^3) - ...
              U*A*(x(6)-x(7)))/(x(8)*((1-w_AS)*Cp_L + Cp_AS*w_AS));    % [degC/s]

dxdt(7,1) = (F_C*Cp_L*(T0_C - x(7)) + U*A*(x(6) - x(7)))/(V_j*rho_L*Cp_L); % [degC/s]

dxdt(8,1) = F_AS;                                      % [kg/s]
end