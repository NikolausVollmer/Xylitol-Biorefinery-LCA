clear; clc; close all;

outs =  ["NPV", "Xylitol", "Succinic_Acid", "El_Net"];
cIDs = [1,3,4,9,11,12,17,19,20,25,27,28];
Ns = [500];

for d=1:length(cIDs)
    for e=1:length(Ns)
        for g=1:length(outs)
            cID = cIDs(d);
            N = Ns(e);
            out = outs(g);

            load(sprintf("c%d_ANNs_%d_cval_%s",cID,N,out),'myANN','annR2','annRMSE',...
                                                          'muX','sigX','muy','sigy');
            
            if out == "NPV"
                npvANN= myANN;
                npvR2 = annR2;
                npvRMSE = annRMSE;
                npvMX = muX;
                npvMY = muy;
                npvSX = sigX;
                npvSY = sigy;
                
            elseif out == "Xylitol"
                xyoANN = myANN;
                xyoR2 = annR2;
                xyoRMSE = annRMSE;
                xyoMX = muX;
                xyoMY = muy;
                xyoSX = sigX;
                xyoSY = sigy;
                
            elseif out == "Succinic_Acid"
                sucANN = myANN;
                sucR2 = annR2;
                sucRMSE = annRMSE;
                sucMX = muX;
                sucMY = muy;
                sucSX = sigX;
                sucSY = sigy;
                
            elseif out == "El_Net"
                pelANN = myANN;
                pelR2 = annR2;
                pelRMSE = annRMSE;
                pelMX = muX;
                pelMY = muy;
                pelSX = sigX;
                pelSY = sigy;             
                
            end          

        end
        
       save(sprintf("c%d_ANN_%d_opt",cID,N),'npvANN','npvR2','npvRMSE',...
                                            'npvMX','npvMY','npvSX','npvSY',...
                                            'xyoANN','xyoR2','xyoRMSE',...
                                            'xyoMX','xyoMY','xyoSX','xyoSY',...
                                            'sucANN','sucR2','sucRMSE',...
                                            'sucMX','sucMY','sucSX','sucSY',...
                                            'pelANN','pelR2','pelRMSE',...
                                            'pelMX','pelMY','pelSX','pelSY');
        
    end
end

        