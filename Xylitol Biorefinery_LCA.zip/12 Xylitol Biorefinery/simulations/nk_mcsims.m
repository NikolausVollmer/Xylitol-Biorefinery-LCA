clear
close all
clc

addpath("../sampling")
addpath("../models")

% rng(42,'twister')

[T, configIDs] = nk_ctable;

cIDs     = [1,2,3,4,9,10,11,12,17,18,19,20,25,26,27,28];

for cID = cIDs

configID = configIDs{cID}; 
space    = nk_designSpace(configID); show(space);
N        = 1000;

% Sampling without boundary points
X        = nk_sampleLHS(N,space.LowerBounds,space.UpperBounds);

%% Simulations
mcsfolder = sprintf('c%d_mcsims',cID); % name of the folder where for iters are stored
if ~exist(mcsfolder, 'dir'), mkdir(mcsfolder); end
 
% perform mcsims
for i=1:N
    try
        % Start Aspen
        if mod(N+1-i,100) == 0      
            HF = StartAspen("HF");
            CF = StartAspen("CF");
            LF = StartAspen("LF");

            Aspen = struct("HF", HF, "CF", CF, "LF", LF);
        end
        
        fprintf('Configuration ID %d, started run %d. ',cID,i);
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        if exist(filename,'file')==2
            continue;
        end

        % full input space
        x = X(i,:);
        [KPI, Mass] = nk_runfs(x,space,configID,Aspen)

        m=matfile(filename,'writable',true); m.KPI=KPI; m.Mass = Mass;
        fprintf('Finished a successful run.\n')
        
        % close Aspen
        if mod(i,100) == 0            
            CloseAspen(CF);
            CloseAspen(HF);
            CloseAspen(LF);
            
            clear Aspen CF HF LF
        end
        
        
    catch ME
        fprintf('Hit an error.\n')
        rethrow(ME)
    end
end

% collect completed sims
for i=1:N
    try
        filename = fullfile(mcsfolder, sprintf('row%d',i));
        m=matfile(filename,'writable',true);
        D(i).KPI  = m.KPI;
        D(i).Mass = m.Mass;
    catch ME
        D(i).KPI  = NaN;
        D(i).Mass = Mass;
        %rethrow(ME)
    end
end


% Put all KPIs and Masses into a table T
S = struct;
fnames = fields(D(1).KPI);
gnames = fields(D(1).Mass);

for i=1:numel(D)
    for j=1:numel(fnames)
        try
            S(i).(fnames{j}) = D(i).KPI.(fnames{j});
        catch
            S(i).(fnames{j}) = NaN;
        end
    end
    
    for j=1:numel(gnames)
        try
            S(i).(gnames{j}) = D(i).Mass.(gnames{j});
        catch
            S(i).(gnames{j}) = NaN;
        end
    end
end

To = struct2table(S) % convert to a table        
Ti = array2table(X,'VariableNames',space.ParNames);

writetable(Ti,sprintf("C%di_%d.csv",cID,N))
writetable(To,sprintf("C%do_%d.csv",cID,N))

% Save run
save(sprintf("c%d_MCS",cID))

end
