function [T, designIDs] = nk_ctable()
    % Returns a table of configurations
    % All processes include pretreatment, optional upstream units, a
    % processing unit, optional upconcentration unit, a purification unit
    % and an optional second purification unit
    
    pretreatment = 'PT';
    hf_upstream = {'UH','bypass'};
    hf_process = 'FX';
    hf_upconc = {'EX','bypass'};
    hf_purfc = 'CX1';
    hf_spurfc = {'CX2','bypass'};
    
    enz_hydr = 'EH';
    cf_upstream = {'UC','bypass'};
    cf_process = 'FS';
    cf_upconc = {'ES','bypass'};
    cf_purfc = 'CS1';
    cf_spurfc = {'CS2','bypass'};
    
    lf_pyrolysis = {'LP','bypass'};
    lf_hydrotr = {'LH','bypass'};
    lf_fract = {'LF','bypass'};
        
    designIDs = {};
    % create configuration IDs wrt binary decisions
    for a=1:length(hf_upstream)
        for b=1:length(hf_upconc)
            for c=1:length(hf_spurfc)
                for d=1:length(cf_upstream)
                    for e=1:length(cf_upconc)
                        for f=1:length(hf_spurfc)
                            for g=1:length(lf_pyrolysis)
                                dID ={pretreatment, hf_upstream{a}, hf_process, hf_upconc{b}, hf_purfc, hf_spurfc{c}, ...
                                      enz_hydr, cf_upstream{d}, cf_process, cf_upconc{e}, cf_purfc, cf_spurfc{f}, ...
                                      lf_pyrolysis{g}, lf_hydrotr{g}, lf_fract{g}};

                                designIDs{end+1,1} = dID; % to get all dids, designIDs{:}
                            end
                        end  
                    end
                end
            end
        end
    end
    
    didc = {};
    for d=1:length(designIDs), did=designIDs{d}; didc{d,1}=strjoin(did,'-'); end
    T = table; 
    T.cID=[1:length(didc)]'; 
    T.configID = didc;
    
end