function Y = nk_process(X,model)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


    switch model 
        case 'pretreatment'
            for i = 1:length(X)
                
                m_biomass = 50000;
                c_in   = [31.3 0 42.7 0 2.6 0 5 0 0 0 0 18.4 0 0 0];
                stats  = [X(i,1:3) 0.1]; % using the sampled decision vars

                [m_hydrolyzate,c_out_hydrolyzate,m_residual,c_out_residual] = pretreatment_model(m_biomass,c_in,stats);

                % post process the outputs
%                 Y(i,1) = m_hydrolyzate * c_out_hydrolyzate(2) / 100; % xylose_mass
%                 Y(i,2) = m_hydrolyzate * c_out_hydrolyzate(4) / 100; % glucose_mass
                Y(i,1) = c_out_hydrolyzate(2); % xylose_mass
                Y(i,2) = c_out_hydrolyzate(4); % glucose_mass
            end


        case'fermentation_xylitol'

            for i = 1:length(X)
                
                m = 41367;
                c_in = [0 2.1278 0 0.1471 0 0.2128 0 0.0025 0.2865 0.0206 0.0069 0.0808 0 0 0];
                stats = X(i,1:2);

                [m_broth, c_out, M_O2_in, M_CO2_out, M_nitro, M_titr] = fermentation_model_xylitol(m,c_in,stats);

                Y(i,1) = c_out(15);

            end

        case 'evaporation_xylitol'

            for i = 1:length(X)
                
                m = 41192;
                c_in = [0 0 0 0 0 0 0 0.0025 0.2877 0.0207 0.0069 0 0 0 0.6058];
                stats = X(i,1:3);

                [m_liquid, c_out_l, m_vapor, c_out_v] = evaporation_model(m,c_in,stats);

                Y(i,1) = c_out_l(15);
                
            end

        case 'crystallization_xylitol'

            for i = 1:length(X)
                                
                m_liquid = 431.37;
                c_in = [0 0 0 0.1477 0 0.2137 0 0.0011 0.2098 1.7228 0.0014 0 0 0 57.8415];
                stats = X(i,1:4);
                
                [m_out, c_out, m_cryst] = crystallization_xylitol(m_liquid, c_in, stats);
                
                Y(i,1) = m_cryst;
                
            end
    end
end

